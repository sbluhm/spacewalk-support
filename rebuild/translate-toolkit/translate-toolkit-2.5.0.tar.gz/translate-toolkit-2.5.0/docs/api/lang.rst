lang
====

.. automodule:: translate.lang
   :show-inheritance:


af
--

.. automodule:: translate.lang.af
   :members:
   :inherited-members:


am
--

.. automodule:: translate.lang.am
   :members:
   :inherited-members:


ar
--

.. automodule:: translate.lang.ar
   :members:
   :inherited-members:


bn
--

.. automodule:: translate.lang.bn
   :members:
   :inherited-members:


code_or
-------

.. automodule:: translate.lang.code_or
   :members:
   :inherited-members:


common
------

.. automodule:: translate.lang.common
   :members:
   :inherited-members:


data
----

.. automodule:: translate.lang.data
   :members:
   :inherited-members:


de
--

.. automodule:: translate.lang.de
   :members:
   :inherited-members:


el
--

.. automodule:: translate.lang.el
   :members:
   :inherited-members:


es
--

.. automodule:: translate.lang.es
   :members:
   :inherited-members:


factory
-------

.. automodule:: translate.lang.factory
   :members:
   :inherited-members:


fa
--

.. automodule:: translate.lang.fa
   :members:
   :inherited-members:


fi
--

.. automodule:: translate.lang.fi
   :members:
   :inherited-members:


fr
--

.. automodule:: translate.lang.fr
   :members:
   :inherited-members:


gu
--

.. automodule:: translate.lang.gu
   :members:
   :inherited-members:


he
--

.. automodule:: translate.lang.he
   :members:
   :inherited-members:


hi
--

.. automodule:: translate.lang.hi
   :members:
   :inherited-members:


hy
--

.. automodule:: translate.lang.hy
   :members:
   :inherited-members:


identify
--------

.. automodule:: translate.lang.identify
   :members:
   :inherited-members:


ja
--

.. automodule:: translate.lang.ja
   :members:
   :inherited-members:


km
--

.. automodule:: translate.lang.km
   :members:
   :inherited-members:


kn
--

.. automodule:: translate.lang.kn
   :members:
   :inherited-members:


ko
--

.. automodule:: translate.lang.ko
   :members:
   :inherited-members:


ml
--

.. automodule:: translate.lang.ml
   :members:
   :inherited-members:


mr
--

.. automodule:: translate.lang.mr
   :members:
   :inherited-members:


ne
--

.. automodule:: translate.lang.ne
   :members:
   :inherited-members:


ngram
-----

.. automodule:: translate.lang.ngram
   :members:
   :inherited-members:


pa
--

.. automodule:: translate.lang.pa
   :members:
   :inherited-members:


poedit
------

.. automodule:: translate.lang.poedit
   :members:
   :inherited-members:


si
--

.. automodule:: translate.lang.si
   :members:
   :inherited-members:


st
--

.. automodule:: translate.lang.st
   :members:
   :inherited-members:


sv
--

.. automodule:: translate.lang.sv
   :members:
   :inherited-members:


ta
--

.. automodule:: translate.lang.ta
   :members:
   :inherited-members:


team
----

.. automodule:: translate.lang.team
   :members:
   :inherited-members:


te
--

.. automodule:: translate.lang.te
   :members:
   :inherited-members:


th
--

.. automodule:: translate.lang.th
   :members:
   :inherited-members:


ug
--

.. automodule:: translate.lang.ug
   :members:
   :inherited-members:


ur
--

.. automodule:: translate.lang.ur
   :members:
   :inherited-members:


vi
--

.. automodule:: translate.lang.vi
   :members:
   :inherited-members:


zh
--

.. automodule:: translate.lang.zh
   :members:
   :inherited-members:
