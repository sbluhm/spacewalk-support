services
========

.. automodule:: translate.services
   :show-inheritance:


tmserver
--------

.. automodule:: translate.services.tmserver
   :members:
   :inherited-members:
