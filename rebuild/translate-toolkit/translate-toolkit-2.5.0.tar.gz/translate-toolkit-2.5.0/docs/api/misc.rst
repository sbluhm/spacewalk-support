misc
====

.. automodule:: translate.misc
   :show-inheritance:


dictutils
---------

.. automodule:: translate.misc.dictutils
   :members:
   :inherited-members:


file_discovery
--------------

.. automodule:: translate.misc.file_discovery
   :members:
   :inherited-members:


lru
---

.. automodule:: translate.misc.lru
   :members:
   :inherited-members:


multistring
-----------

.. automodule:: translate.misc.multistring
   :members:
   :inherited-members:


optrecurse
----------

.. automodule:: translate.misc.optrecurse
   :members:
   :inherited-members:


ourdom
------

.. automodule:: translate.misc.ourdom
   :members:
   :inherited-members:


progressbar
-----------

.. automodule:: translate.misc.progressbar
   :members:
   :inherited-members:


quote
-----

.. automodule:: translate.misc.quote
   :members:
   :inherited-members:


wsgi
----

.. automodule:: translate.misc.wsgi
   :members:
   :inherited-members:


wStringIO
---------

.. automodule:: translate.misc.wStringIO
   :members:


xml_helpers
-----------

.. automodule:: translate.misc.xml_helpers
   :members:
   :inherited-members:
