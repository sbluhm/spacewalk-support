tools
=====

.. automodule:: translate.tools
   :show-inheritance:


build_tmdb
----------

.. automodule:: translate.tools.build_tmdb
   :members:
   :inherited-members:


phppo2pypo
----------

.. automodule:: translate.tools.phppo2pypo
   :members:
   :inherited-members:


poclean
-------

.. automodule:: translate.tools.poclean
   :members:
   :inherited-members:


pocompile
---------

.. automodule:: translate.tools.pocompile
   :members:
   :inherited-members:


poconflicts
-----------

.. automodule:: translate.tools.poconflicts
   :members:
   :inherited-members:


pocount
-------

.. automodule:: translate.tools.pocount
   :members:
   :inherited-members:


podebug
-------

.. automodule:: translate.tools.podebug
   :members:
   :inherited-members:


pogrep
------

.. automodule:: translate.tools.pogrep
   :members:
   :inherited-members:


pomerge
-------

.. automodule:: translate.tools.pomerge
   :members:
   :inherited-members:


porestructure
-------------

.. automodule:: translate.tools.porestructure
   :members:
   :inherited-members:


posegment
---------

.. automodule:: translate.tools.posegment
   :members:
   :inherited-members:


poswap
------

.. automodule:: translate.tools.poswap
   :members:
   :inherited-members:


poterminology
-------------

.. automodule:: translate.tools.poterminology
   :members:
   :inherited-members:


pretranslate
------------

.. automodule:: translate.tools.pretranslate
   :members:
   :inherited-members:


pydiff
------

.. automodule:: translate.tools.pydiff
   :members:
   :inherited-members:


pypo2phppo
----------

.. automodule:: translate.tools.pypo2phppo
   :members:
   :inherited-members:
