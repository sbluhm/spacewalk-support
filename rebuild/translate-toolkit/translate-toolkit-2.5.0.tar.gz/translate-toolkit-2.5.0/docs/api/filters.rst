filters
=======

.. automodule:: translate.filters
   :show-inheritance:


autocorrect
-----------

.. automodule:: translate.filters.autocorrect
   :members:
   :inherited-members:


checks
------

.. automodule:: translate.filters.checks
   :members:
   :inherited-members:


decoration
----------

.. automodule:: translate.filters.decoration
   :members:
   :inherited-members:


helpers
--------

.. automodule:: translate.filters.helpers
   :members:
   :inherited-members:


pofilter
--------

.. automodule:: translate.filters.pofilter
   :members:
   :inherited-members:


prefilters
----------

.. automodule:: translate.filters.prefilters
   :members:
   :inherited-members:


spelling
--------

.. automodule:: translate.filters.spelling
   :members:
   :inherited-members:
