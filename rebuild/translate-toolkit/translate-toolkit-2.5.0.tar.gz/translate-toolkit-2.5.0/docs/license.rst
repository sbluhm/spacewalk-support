
.. _license:
.. _copyright:

License
*******

The Translate Toolkit documentation is released under the `GNU General Public
License (GPL) <http://www.gnu.org/licenses/gpl.html>`_.

