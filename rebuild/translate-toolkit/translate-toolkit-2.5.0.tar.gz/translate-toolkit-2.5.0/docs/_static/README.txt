In this directory go static files, for example images.
