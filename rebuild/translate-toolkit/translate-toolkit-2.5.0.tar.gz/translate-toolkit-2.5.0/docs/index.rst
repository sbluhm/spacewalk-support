.. _translate-toolkit:

Translate Toolkit
=================

Welcome to Translate Toolkit's documentation. This documentation covers both
user's and programmer's perspective.

.. toctree::
   :maxdepth: 2


.. include:: contents.rst.inc
