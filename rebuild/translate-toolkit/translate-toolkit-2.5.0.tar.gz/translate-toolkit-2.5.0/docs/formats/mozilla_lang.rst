.. _mozilla_lang:

Mozilla .lang files
*******************

Mozilla's custom `.lang
<https://github.com/mozilla-l10n/langchecker/wiki/.lang-files-format>`_ format
is used for some of their websites.


.. _mozilla_langd#references:

References
==========

* .lang `specification
  <https://github.com/mozilla-l10n/langchecker/wiki/.lang-files-format>`_
* `www.mozilla.org repository
  <https://github.com/mozilla-l10n/www.mozilla.org>`_ of translations
