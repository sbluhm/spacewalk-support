
.. _wml:

Wireless Markup Language
************************
This page documents the support for :wp:`WML <Wireless_Markup_Language>` and is
used for planning our work on it.

This is implemented as a generic XML document type that is handled similarly to
the way the :wiki:`developers/projects/odf` project handles ODF documents.
