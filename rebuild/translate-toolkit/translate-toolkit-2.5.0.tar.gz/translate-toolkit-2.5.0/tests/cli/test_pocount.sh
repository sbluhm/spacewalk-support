#!/bin/bash

source $(dirname $0)/test.inc.sh

pocount
start_checks
startswithi_stderr "Usage"
end_checks
