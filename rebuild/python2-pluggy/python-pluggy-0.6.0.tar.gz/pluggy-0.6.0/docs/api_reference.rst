Api Reference
=============

.. automodule:: pluggy
    :members:
    :undoc-members:
    :show-inheritance:


.. automethod:: pluggy._Result.get_result

.. automethod:: pluggy._Result.force_result

.. automethod:: pluggy._HookCaller.call_extra
