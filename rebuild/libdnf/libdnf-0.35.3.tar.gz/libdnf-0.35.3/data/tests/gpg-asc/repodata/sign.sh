gpg --homedir ../../gpgkey/ --armor --detach-sig repomd.xml
