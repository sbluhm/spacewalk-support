:tocdepth: 2

.. _examples:

.. include:: ../EXAMPLES
