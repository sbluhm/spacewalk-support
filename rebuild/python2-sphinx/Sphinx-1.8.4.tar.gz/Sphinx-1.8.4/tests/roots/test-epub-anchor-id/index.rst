test-epub-anchor-id
===================

.. setting:: STATICFILES_FINDERS

blah blah blah

see :setting:`STATICFILES_FINDERS`
