from bug2437.autodoc_dummy_foo import Foo


class Bar(object):
    """Dummy class Bar with alias."""
    my_name = Foo
