Index markup
------------

.. index::
   single: entry
   pair: entry; pair
   double: entry; double
   triple: index; entry; triple
   keyword: with
   see: from; to
   seealso: fromalso; toalso

.. index::
   !Main, !Other
   !single: entry; pair

.. index:: triple-quoted string, Unicode Consortium, raw string
   single: """; string literal
   single: '''; string literal
