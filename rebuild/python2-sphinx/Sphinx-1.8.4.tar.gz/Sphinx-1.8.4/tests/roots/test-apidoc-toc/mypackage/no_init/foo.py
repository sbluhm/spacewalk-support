MESSAGE = "There's no __init__.py in this folder, hence we should be left out"
