module_option
=============

.. py:class:: B
   :module: test.extra

   This is also a test.


   .. py:method:: B.baz()
      :module: test.extra

      Does something similar to :meth:`foo`.


   .. py:method:: B.foo()
      :module: test.extra

      Does something.


   .. py:method:: B.test()
      :module: test.extra

      Does something completely unrelated to :meth:`foo`
