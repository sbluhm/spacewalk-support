# -*- coding: utf-8 -*-

project = 'Sphinx docutils conf <Tests>'
source_suffix = '.txt'
keep_warnings = True
exclude_patterns = ['_build']
