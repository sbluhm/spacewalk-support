# pylint: disable = invalid-name, missing-docstring, unused-variable, unused-argument
def function(hello):
    x, y, z = (1,2,3,) # [bad-whitespace, bad-whitespace, missing-final-newline]