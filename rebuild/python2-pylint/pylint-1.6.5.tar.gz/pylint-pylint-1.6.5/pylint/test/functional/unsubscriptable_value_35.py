# pylint: disable=missing-docstring, invalid-name

import typing

val = typing.Sequence[int]
