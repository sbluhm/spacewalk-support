.. toctree::
   :titlesonly:
   :maxdepth: 1

   features