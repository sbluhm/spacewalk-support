#!/bin/bash

py.test $1 -v -s
