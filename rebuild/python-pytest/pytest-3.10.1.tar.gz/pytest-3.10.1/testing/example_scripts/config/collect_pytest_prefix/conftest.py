class pytest_something(object):
    pass
