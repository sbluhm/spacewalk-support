def test_foo():
    pass
