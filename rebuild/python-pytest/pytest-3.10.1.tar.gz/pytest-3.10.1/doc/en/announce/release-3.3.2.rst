pytest-3.3.2
=======================================

pytest 3.3.2 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at http://doc.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Anthony Sottile
* Antony Lee
* Austin
* Bruno Oliveira
* Florian Bruhin
* Floris Bruynooghe
* Henk-Jaap Wagenaar
* Jurko Gospodnetić
* Ronny Pfannschmidt
* Srinivas Reddy Thatiparthy
* Thomas Hisch


Happy testing,
The pytest Development Team
