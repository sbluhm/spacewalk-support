package org.specs2

object all extends runner.FilesRunner