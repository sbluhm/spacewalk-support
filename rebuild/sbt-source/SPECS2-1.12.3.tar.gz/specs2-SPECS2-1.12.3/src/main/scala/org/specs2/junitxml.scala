package specs2

/**
 * runner creating junit xml reports
 */
object junitxml extends org.specs2.runner.JUnitXmlRunner