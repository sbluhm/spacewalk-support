package specs2

/**
 * runner creating html pages
 */
object html extends org.specs2.runner.HtmlRunner