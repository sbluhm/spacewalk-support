[Google Code]: http://code.google.com/p/simple-build-tool
[CONTRIBUTING]: https://github.com/sbt/sbt/blob/0.13/CONTRIBUTING.md
[Setup]: http://www.scala-sbt.org/release/docs/Getting-Started/Setup
[FAQ]: http://www.scala-sbt.org/release/docs/faq

# sbt 0.13

This is the 0.13.x series of sbt.

 * [Setup]: Describes getting started with the latest binary release.
 * See [CONTRIBUTING] for how to build from source, open an issue, fix or add documentation, or submit a pull request.
 * [FAQ]: Explains how to get help and more.
 * [Google Code]: hosts sbt 0.7.7 and earlier versions