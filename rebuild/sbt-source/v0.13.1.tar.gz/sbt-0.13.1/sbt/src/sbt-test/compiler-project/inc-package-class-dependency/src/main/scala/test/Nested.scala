package test

trait Nested
