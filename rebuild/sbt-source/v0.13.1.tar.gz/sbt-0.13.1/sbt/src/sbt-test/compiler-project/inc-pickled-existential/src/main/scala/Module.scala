package test6

class Module[T]
