class A {
	def initialized: Boolean = false
}
