package test3

class Impl extends B with A with C {
  def bleep = println("foo")
}
