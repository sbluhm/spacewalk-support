object B {
	def x(i: Int) = 3
}
