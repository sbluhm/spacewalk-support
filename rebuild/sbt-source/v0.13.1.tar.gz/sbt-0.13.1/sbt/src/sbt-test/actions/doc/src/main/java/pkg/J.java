package pkg;
/** This is class J */
public class J {
}