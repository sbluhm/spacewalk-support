object Main{

}
