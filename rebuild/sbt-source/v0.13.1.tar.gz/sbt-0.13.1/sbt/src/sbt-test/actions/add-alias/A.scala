object A extends App {
  if(args(0).toBoolean) () else error("Fail")
}
