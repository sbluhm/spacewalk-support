// Java allows the main class to have default access, test that here
class A{
  public static void main(String... args){

  }
}
