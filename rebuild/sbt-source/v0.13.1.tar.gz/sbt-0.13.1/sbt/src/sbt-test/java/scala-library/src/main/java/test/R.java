package test;

public final class R {
   public static final int y = 4;
   public static int x(scala.Product s) { return 3; }
}
