object Test
{
	def main(args: Array[String])
	{
		println(new a.A)
	}
}