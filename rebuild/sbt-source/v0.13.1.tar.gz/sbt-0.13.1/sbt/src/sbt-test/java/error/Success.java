package test;

public class Success {}