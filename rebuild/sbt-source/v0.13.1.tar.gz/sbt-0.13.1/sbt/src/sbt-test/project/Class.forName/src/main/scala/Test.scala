package injar

object Test
{
	def other = Class.forName("injar.OtherTest")
}

class OtherTest