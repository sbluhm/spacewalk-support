package a;

public class JavaB
{
	public int dec(int i) { return i-1; }
}