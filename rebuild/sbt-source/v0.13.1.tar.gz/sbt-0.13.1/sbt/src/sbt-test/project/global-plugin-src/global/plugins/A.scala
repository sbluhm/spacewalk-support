package test

object Global {
  val x = 3
}
