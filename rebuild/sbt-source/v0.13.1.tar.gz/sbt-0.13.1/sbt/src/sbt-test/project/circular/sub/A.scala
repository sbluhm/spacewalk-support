object A {
  def x = B.x
}
