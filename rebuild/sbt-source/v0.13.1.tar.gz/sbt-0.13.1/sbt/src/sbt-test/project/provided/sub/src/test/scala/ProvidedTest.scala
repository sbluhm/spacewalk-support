package org.example

class ProvidedTest