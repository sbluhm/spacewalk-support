object A {
  val x = B.x
}
