object A {
 val x = 5
}
