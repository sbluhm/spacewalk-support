package jartest

object Main
{
	def main(args: Array[String]) {}
}