import sbinary._

trait B
{
	def format(a: A): Format[A]
}