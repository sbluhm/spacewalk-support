object A { val x = 3 }
