public final class B {
	public static void main(String[] args) {
		System.out.println(A.x);
	}
}
