import sbinary._

trait A
{
	def format: Format[A]
}