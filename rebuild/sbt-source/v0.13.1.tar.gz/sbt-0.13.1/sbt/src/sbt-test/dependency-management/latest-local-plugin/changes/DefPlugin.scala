import sbt._
import Keys._

object DefPlugin extends Plugin {
  val aValue = "demo"
}
