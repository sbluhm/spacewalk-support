object B { val y = A.x }
