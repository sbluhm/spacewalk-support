object PublishedIvy
{
	val x = 4
}