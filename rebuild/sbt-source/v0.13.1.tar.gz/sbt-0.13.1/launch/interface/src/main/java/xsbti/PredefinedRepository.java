package xsbti;

public interface PredefinedRepository extends Repository
{
	Predefined id();
}
