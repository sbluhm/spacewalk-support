package xsbti;

public interface Repository {}