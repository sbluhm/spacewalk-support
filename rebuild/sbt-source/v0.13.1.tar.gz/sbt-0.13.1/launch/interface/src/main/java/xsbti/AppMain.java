package xsbti;

public interface AppMain
{
	public MainResult run(AppConfiguration configuration);
}