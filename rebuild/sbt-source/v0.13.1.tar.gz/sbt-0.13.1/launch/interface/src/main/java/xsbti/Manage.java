package xsbti;

enum Manage
{
	Nop, Clean, Refresh;
}