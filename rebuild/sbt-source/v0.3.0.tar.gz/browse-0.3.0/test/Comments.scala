class Comments {
	
	// A single line comment
	val x = 3

	/* A plain comment */
	def y(c: List[Double]): Int = ???

	/** A doc comment
	* @param t A parameter
	*/
	def z[T](t: T): T = t

}