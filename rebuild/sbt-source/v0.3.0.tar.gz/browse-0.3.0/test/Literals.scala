object Literals {
	val a = 3.0
	val aa: Double = 3.0

	val b = 4
	val bb: Int = 4

	val c = 5.0f
	val cc: Float = 5.0f

	val d = true
	val dd: Boolean = false

	val e = "asdf"
	val ee: String = "asdf"

	val f = ()
	val ff: Unit = ()

	val g = 93L
	val gg: Long = 93L

	val s = 'asymbol
	val ss: Symbol = 'a

	val h = 'c'
	val hh: Char = 'c'
}