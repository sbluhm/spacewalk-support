class If {
	def x(flag: Boolean) = if(flag) 1823 else false
}