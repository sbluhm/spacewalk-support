lazy_object_proxy
=================

.. testsetup::

    from lazy_object_proxy import *

.. automodule:: lazy_object_proxy
    :members:
