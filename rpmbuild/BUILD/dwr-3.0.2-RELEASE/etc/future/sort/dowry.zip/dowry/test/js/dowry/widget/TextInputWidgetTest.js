$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.TextInputWidget");
$import("dowry.test.Test");

$class("TextInputWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.TextInputWidget();
	}
});