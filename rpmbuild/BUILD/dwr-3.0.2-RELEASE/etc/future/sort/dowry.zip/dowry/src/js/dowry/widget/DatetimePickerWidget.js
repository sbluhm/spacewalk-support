$package("dowry.widget");

/**
 * DatetimePickerWidget is just like DatePicker, except the
 * popup calendar includes a picker for time as well.
 *
 * <p>
 * This class uses
 * <a href="http://www.dynarch.com/projects/calendar">
 * JSCalendar</a> to provide the popup calendar
 * functionality.  Since this code is not bundled with
 * Dowry, please be sure to include the associated
 * scripts, stylesheets, etc. for this external library.
 * </p>
 *
 */
$class("DatetimePickerWidget").$extends("DatePickerWidget").$as(
{
    /**
     * Extends the default <code>getJsCalendarParams()
     * </code> to include the <code>showsTime</code>
     * property with a 12-hour <code>timeFormat</code>.
     *
     * @return  an object containing the JSCalendar
     *          parameters
     *
     */
    getJsCalendarParams : function()
    {
		var params = this.$super(arguments);
		params.showsTime = true;
		params.timeFormat = 12;
		return params;
    }
});