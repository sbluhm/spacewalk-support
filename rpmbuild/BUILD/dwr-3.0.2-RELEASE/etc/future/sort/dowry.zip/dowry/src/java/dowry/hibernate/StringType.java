package dowry.hibernate;

import java.util.*;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.Column;
import dowry.*;

/**
 * Object representation of a String datatype.
 *
 */
public class StringType
    extends dowry.datatype.StringType
    implements HibernateType
{
	/**
	 * Generates a map of attributes for the specified
	 * Hibernate property, based on the rules of this
	 * datatype.
	 *
	 * @param entityMapper  a handle back to the entity
	 *                      mapper processing the Hibernate
	 *                      configuration
	 *
	 * @param property      the Hibernate property
	 *
	 * @return              a Map containing the relevant
	 *                      Dowry attributes
	 *
	 */
	public Map toConfiguration(HibernateEntityMapper entityMapper,
	                           Property property)
	{
		Map cfg = new HashMap();

		String propertyType = entityMapper.getPropertyType(property);
		cfg.put(JAVA_CLASS, propertyType);
		cfg.put(TYPE, entityMapper.toType(propertyType));
		cfg.put(REQUIRED, new Boolean(!property.isOptional()));

		// loop through this type's columns
		Iterator columnIter = property.getColumnIterator();
		while (columnIter.hasNext())
		{
			// surprisingly, the column iterator
			// does not always return objects
			// assignable to column... so we will
			// be cautious...
			Object o = columnIter.next();
			if (o != null && o instanceof Column)
			{
				Column column = (Column) o;

				int len = column.getLength();

				// make sure length is actually defined...
				if (len != Column.DEFAULT_LENGTH)
				{
					cfg.put(LENGTH, new Integer(len));
					break;
				}
			}
		}

        return cfg;
	}
}