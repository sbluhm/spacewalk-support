$package("dowry.datatype");

/**
 * Object representation of a datetime datatype.   This only
 * differs from DateType in that it contains the appropriate
 * <code>full</code>, <code>long</code>, <code>medium
 * </code>, and <code>short</code> patterns for datetime
 * data.
 *
 */
$class("DatetimeType").$extends("DateType").$as(
{
    /**
     * Constant for the parse/format mask to use with the
     * full date format.
     *
     */
    FULL : Dowry.msgs.getMessage("datetimeFullPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * long date format.
     *
     */
    LONG : Dowry.msgs.getMessage("datetimeLongPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * medium date format.
     *
     */
    MEDIUM : Dowry.msgs.getMessage("datetimeMediumPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * short date format.
     *
     */
    SHORT : Dowry.msgs.getMessage("datetimeShortPattern")
});