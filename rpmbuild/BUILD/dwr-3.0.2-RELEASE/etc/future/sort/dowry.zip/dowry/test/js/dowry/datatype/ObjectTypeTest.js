$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.ObjectType");
$import("dowry.test.Test");

$class("ObjectTypeTest").$extends("Test").$as(
{
	test : function()
	{
		var dt = new dowry.datatype.ObjectType();
	}
});