package dowry;

import java.util.*;

/**
 * DowryService is an interface for a DWR exposed service
 * for handling Dowry's remote validation and remote
 * class loading.
 *
 */
public interface DowryService
{
	/**
	 * Returns Javascript resources using the classloader.
	 *
	 * @param  className  the Javascript classname
	 *
	 * @return            the raw Javascript as a string
	 *
	 */
	public String loadJs(String className);

	/**
	 * Validates the provided configuration using the
	 * appropriate Dowry datatype.
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      the string validation error message,
	 *              if the validation fails; null otherwise
	 *
	 */
	public String validate(HashMap cfg);

	/**
	 * Validates a JavaBean object using the configuration
	 * information provided by the entity mapper for the
	 * specified entity name.  It wll return a map
	 * containing the results in the format: bean property
	 * name => message.
	 *
	 * @param bean        the JavaBean object to be
	 *                    validated
	 *
	 * @param entityName  the entity to validate this object
	 *                    as
	 *
	 * @return            a map containing any validation
	 *                    errors
	 *
	 */
	public Map validateBean(Object bean, String entityName);

	/**
	 * Validates a JavaBean object using the raw
	 * configuration information provided.  This
	 * configuration information should be in the entity
	 * mapper format of:
	 *
	 * <pre>
 	 * Map&lt;String property,
	 *     Map&lt;String attribute, Object value&gt;&gt;
	 * </pre>
	 *
	 * <p>
	 * It wll return a map containing the results in the
	 * format: bean property name => message.
	 * </p>
	 *
	 * @param bean        the JavaBean object to be
	 *                    validated
	 *
	 * @param properties  a map with the entity's properties
	 *
	 * @return            a map containing any validation
	 *                    errors
	 *
	 */
	public Map validateBean(Object bean, Map properties);

	/**
	 * Performs multiple validations as a single operation.
	 * It wll return a map containing the results in the
	 * format: id => message.
	 *
	 * @param  cfg  an array of maps, each containing all
	 *              the configuration information relevant
	 *              to the local representation of this
	 *              datatype
	 *
	 * @return      a map containing keys representing the
	 *              string id of this configuration, mapped
	 *              to the string validation error message
	 *
	 */
	public Map validateMany(HashMap[] cfg);
}