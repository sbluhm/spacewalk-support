$package("org.example.util");

$mixin("Trimmable").$extends("Debuggable").$as(
{
	trim : function(s)
	{
		alert("[TRIMMABLE] trim");
		return this.$super(arguments);
	}
});