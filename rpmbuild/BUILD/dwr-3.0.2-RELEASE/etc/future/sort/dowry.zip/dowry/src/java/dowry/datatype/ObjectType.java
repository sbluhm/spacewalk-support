package dowry.datatype;

import java.util.*;
import dowry.*;

/**
 * Object representation of an object datatype.
 *
 */
public class ObjectType extends AbstractType
{
	/**
	 * Constant for the configuration key containing the
	 * datatype's <code>key</code> property indicating the
	 * string name of the field on the object where the
	 * value goes.
	 *
	 */
	 public static final String KEY = "key";

	/**
	 * Gets the name of the Javascript class that serves
	 * as the client side equivalent to this Java Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass()
	{
		return ObjectType.class.getName();
	}

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName)
	{
		return (typeName != null && typeName.indexOf(ENTITY_PREFIX) > -1);
	}

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * <p>
	 * This implementation returns the the prefix 'entity_'
	 * followed by the class name, with the package stripped
	 * off.  This may cause collisions, if you have classes
	 * of the same name in different packaged with different
	 * identifier properties.  If so, override this method
	 * with a more suitable behavior.
	 * </p>
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c)
	{
		String type = null;

		if (c != null)
		{
			type = ENTITY_PREFIX + unqualify(c.getName());
		}

		return type;
	}

	/**
	 * No validation required for an ObjectType, since the
	 * actual validation is performed against the key's
	 * datatype.
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      null
	 *
	 */
	public String validate(Map cfg)
	{
		// TODO: is this right?
		return null;
	}
}