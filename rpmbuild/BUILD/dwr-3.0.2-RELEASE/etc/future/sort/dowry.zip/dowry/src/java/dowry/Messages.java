package dowry;

import java.text.*;
import java.util.*;

/**
 * Utility to get locale-specific string messages, such as
 * Exception messages.  Internally, this class uses the
 * resource bundle 'dowry'... however, it wraps the calls to
 * the bundle such that if no matching message is found, it
 * returns the key itself.
 *
 */
public class Messages
{
	private static ResourceBundle bundle;

	// do a static load of the bundle when
	// we load this class
	static
	{
		try
		{
			bundle = ResourceBundle.getBundle("dowry");
		}
		catch(MissingResourceException ex)
		{
			bundle = null;
		}
	}


	/**
	 * This is a static utility... hide the constructor.
	 *
	 */
	private Messages()
	{
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * @param key  the key to the message in the bundle
	 *
	 */
	public static String get(String key)
	{
		if (bundle != null)
		{
			try
			{
				key = bundle.getString(key);
			}
			catch(MissingResourceException ex)
			{
			}
		}

		// if we can't find bundle... the key
		// is the message
		return key;
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * <p>
	 * This method treats the message in the resource
	 * bundle as a MessageFormat pattern, and formats the
	 * message with the specified arguments.
	 * </p>
	 *
	 * @param key   the key to the message in the bundle
	 *
	 * @param arg   the argument used to construct the
	 *              message
	 *
	 * @return      the localized string message
	 *
	 */
	public static String get(String key, Object arg)
	{
        return get(key, new Object[] { arg });
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * <p>
	 * This method treats the message in the resource
	 * bundle as a MessageFormat pattern, and formats the
	 * message with the specified arguments.
	 * </p>
	 *
	 * @param key   the key to the message in the bundle
	 *
	 * @param arg1  the first argument used to construct
	 *              the message
	 *
	 * @param arg2  the second argument used to construct
	 *              the message
	 *
	 * @return      the localized string message
	 *
	 */
	public static String get(String key, Object arg1, Object arg2)
	{
        return get(key, new Object[] { arg1, arg2 });
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * <p>
	 * This method treats the message in the resource
	 * bundle as a MessageFormat pattern, and formats the
	 * message with the specified arguments.
	 * </p>
	 *
	 * @param key   the key to the message in the bundle
	 *
	 * @param arg1  the first argument used to construct
	 *              the message
	 *
	 * @param arg2  the second argument used to construct
	 *              the message
	 *
	 * @param arg3  the third argument used to construct
	 *              the message
	 *
	 * @return      the localized string message
	 *
	 */
	public static String get(String key,
	                         Object arg1,
	                         Object arg2,
	                         Object arg3)
	{
        return get(key, new Object[] { arg1, arg2, arg3 });
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * <p>
	 * This method treats the message in the resource
	 * bundle as a MessageFormat pattern, and formats the
	 * message with the specified arguments.
	 * </p>
	 *
	 * @param key   the key to the message in the bundle
	 *
	 * @param arg1  the first argument used to construct
	 *              the message
	 *
	 * @param arg2  the second argument used to construct
	 *              the message
	 *
	 * @param arg3  the third argument used to construct
	 *              the message
	 *
	 * @param arg4  the fourth argument used to construct
	 *              the message
	 *
	 * @return      the localized string message
	 *
	 */
	public static String get(String key,
	                         Object arg1,
	                         Object arg2,
	                         Object arg3,
	                         Object arg4)
	{
        return get(key, new Object[] { arg1, arg2, arg3, arg4 });
	}

	/**
	 * Returns the message for the specified key... or
	 * if no matching message is found, it returns the
	 * key itself.
	 *
	 * <p>
	 * This method treats the message in the resource
	 * bundle as a MessageFormat pattern, and formats the
	 * message with the specified arguments.
	 * </p>
	 *
	 * @param key   the key to the message in the bundle
	 *
	 * @param args  an array of arguments used to construct
	 *              the message
	 *
	 * @return      the localized string message
	 *
	 */
	public static String get(String key, Object[] args)
	{
		String pattern = get(key);
		key = MessageFormat.format(pattern, args);

		return key;
	}

	/**
	 * Returns an iteration of the message keys.
	 *
	 * @return   an iterator of the message keys
	 *
	 */
	public static Iterator keys()
	{
		Set keys = new HashSet();

		if (bundle != null)
		{
			Enumeration keysEnum = bundle.getKeys();
			while (keysEnum.hasMoreElements())
			{
				keys.add(keysEnum.nextElement());
			}
		}

		return keys.iterator();
	}
}