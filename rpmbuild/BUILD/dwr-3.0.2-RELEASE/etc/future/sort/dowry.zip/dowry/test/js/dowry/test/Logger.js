$package("dowry.test");

/**
 * Logger logs the results of the TestRunner.  This logger
 * appends a simple HTML table output for the results.
 *
 */
$class("Logger").$as(
{
	/**
	 * Constructs a new Logger instance.
	 *
	 * @param root  (optional)  the root element to append
	 *              the output under
	 *
	 */
	Logger : function(root)
	{
		if (root == null)
		{
			root = document.body;
		}

		var title     = document.createElement("div");
		var div       = document.createElement("div");
		var summary   = document.createElement("div");
		var tbl       = document.createElement("table");
		var thead     = document.createElement("thead");
		var tbody     = document.createElement("tbody");
		var thStatus  = document.createElement("th");
		var thTest    = document.createElement("th");
		var thMsg     = document.createElement("th");
		var txtStatus = document.createTextNode("Status");
		var txtTest   = document.createTextNode("Test");
		var txtMsg    = document.createTextNode("Message");

		title.setAttribute("id", "logtitle");
		tbl.setAttribute("id", "logtable");
		summary.setAttribute("id", "logsummary");

		thStatus.appendChild(txtStatus);
		thTest.appendChild(txtTest);
		thMsg.appendChild(txtMsg);

		thead.appendChild(thStatus);
		thead.appendChild(thTest);
		thead.appendChild(thMsg);

		tbl.appendChild(thead);
		tbl.appendChild(tbody);

		div.appendChild(title);
		div.appendChild(summary);
		div.appendChild(tbl);
		root.appendChild(div);
	},

	/**
	 * Logs the title of this test suite,
	 *
	 * @param name  the title
	 */
	title : function(name)
	{
		var div = document.getElementById("logtitle");
		if (div != null &&
		    name != null)
		{
			div.appendChild(document.createTextNode(name));
		}
	},

	/**
	 * Logs the start of a test.
	 *
	 * @param testName  the name of the test that has
	 *                  started
	 *
	 */
	start : function(testName)
	{
		var tbl = document.getElementById("logtable");
		if (tbl != null &&
		    tbl.tBodies != null)
		{
			var tbody = tbl.tBodies[0];
			if (tbody != null)
			{
				var tr       = document.createElement("tr");
				var tdStatus = document.createElement("td");
				var tdTest   = document.createElement("td");
				var tdMsg    = document.createElement("td");
				var txtTest  = document.createTextNode(testName);

				tdTest.appendChild(txtTest);
				tr.appendChild(tdStatus);
				tr.appendChild(tdTest);
				tr.appendChild(tdMsg);
				tbody.appendChild(tr);
			}
		}
	},

	/**
	 * Logs the provided message for the currently running
	 * test.
	 *
	 * @param msg  the message to be logged
	 *
	 */
	message : function(msg)
	{
		var tbl = document.getElementById("logtable");
		if (tbl != null &&
		    tbl.tBodies != null)
		{
			var tbody = tbl.tBodies[0];
			if (tbody != null)
			{
				var tr = tbody.rows[tbody.rows.length-1];
				if (tr != null)
				{
					var txtMsg = document.createTextNode(msg);
					var tdMsg  = tr.cells[2];
					tdMsg.innerHTML = "";

					tdMsg.appendChild(txtMsg);
				}
			}
		}
	},

	/**
	 * Logs the completion of the currently running test.
	 *
	 * @param status  the status of the completed test

	 * @param msg     the message to be displayed upon
	 *                completion (usually a summary of the
	 *                test results)
	 *
	 */
	finish : function(status, msg)
	{
		var tbl = document.getElementById("logtable");
		if (tbl != null &&
		    tbl.tBodies != null)
		{
			var tbody = tbl.tBodies[0];
			if (tbody != null)
			{
				var tr = tbody.rows[tbody.rows.length-1];
				if (tr != null)
				{
					var txtStatus = document.createTextNode(status);
					var txtMsg    = document.createTextNode(msg);
					var tdStatus  = tr.cells[0];
					var tdMsg     = tr.cells[2];

					tdStatus.innerHTML = "";
					tdMsg.innerHTML = "";

					tdStatus.appendChild(txtStatus);
					tdMsg.appendChild(txtMsg);
					tr.className = status;
				}
			}
		}
	},

	/**
	 * Logs the summary of the test suite.
	 *
	 * @param msg     the summary message
	 *
	 */
	summary: function(msg)
	{
		var div = document.getElementById("logsummary");
		if (div != null)
		{
			while (div.childNodes.length > 0)
			{
				div.removeChild(div.childNodes[0]);
			}

			var txtMsg = document.createTextNode(msg);
			div.appendChild(txtMsg);
		}
	}
});