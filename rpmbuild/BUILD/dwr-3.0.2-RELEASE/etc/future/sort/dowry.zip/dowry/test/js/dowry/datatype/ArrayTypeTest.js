$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.ArrayType");
$import("dowry.test.Test");

$class("ArrayTypeTest").$extends("Test").$as(
{
	test : function()
	{
		var dt = new dowry.datatype.ArrayType();
	}
});