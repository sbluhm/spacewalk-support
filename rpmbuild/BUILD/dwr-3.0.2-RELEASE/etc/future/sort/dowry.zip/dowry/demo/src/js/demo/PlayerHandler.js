$package("demo");

$import("demo.DefaultHandler");

$class("PlayerHandler").$extends("DefaultHandler").$as(
{

	/**
	 * Creates a new instance of the handler.
	 *
	 */
	PlayerHandler : function()
	{
		this.initEvents();
		this.initDropdowns();
		this.initOriginalValue();
		this.initButtons();
	},

	/**
	 * Initialize the buttons on the page.
	 *
	 */
	initButtons : function()
	{
		this.createButton("saveButton",
		                  "Save",
		                  this.preSave,
		                  "buttonBar");
	},

	/**
	 * Initialize the dropdowns with the available options.
	 *
	 */
	initDropdowns : function()
	{
        var func = null;

		// populate our team dropdown
		func = Dowry.addValues.callback("team", $VALUE);
		DemoService.getTeams(func);

		// populate our positions dropdown
		func = Dowry.addValues.callback("positions", $VALUE);
		DemoService.getPositions(func);

	},

	/**
	 * Initialize various Ajax events.
	 *
	 */
	initEvents : function()
	{
		// changes to the positions field require us to
		// re-validate the jersey number
		var func = Dowry.getWidget("jerseyNumber").validate;
		Dowry.event.addEvent("positions", "change", func);

	},

	/**
	 * Initializes the original value.  It does so by
	 * retrieving the id from the query string, and if
	 * present, using that id to fetch the associated
	 * player object.  It then continues page
	 * intiialization.
	 *
	 */
	initOriginalValue : function()
	{
		var obj = Dowry.receiveObject();
		if (obj && obj.id)
		{
			var func = this.populateElements.callback($VALUE);
			DemoService.getPlayer(obj.id, func);
		}
	},

	/**
	 * Populates the HTML elements based on the object model
     * representation.
     *
	 */
	populateElements : function(player)
	{
		Dowry.populateElements("Player", player);
	},

	/**
	 * Populates the object model representation.
	 *
	 */
	populateObject : function()
	{
		return Dowry.populateObject("Player");
	},

	/**
	 * Perform basic pre-save prep work, including
	 * validating the form input.
	 *
	 */
	preSave : function()
	{
		Dowry.validate(this.save);
	},

	/**
	 * Event fired when the user clicks the Save button.
	 *
	 */
	save : function(ok)
	{
		if (ok)
		{
			var val = this.populateObject();
			DemoService.savePlayer(val, this.postSave);
		}
	},

	/**
	 * Post-save?
	 *
	 */
	postSave : function(id)
	{
        Dowry.setValue("id", id);
        alert("saved");
	}

});
