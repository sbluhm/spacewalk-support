package dowry;

import uk.ltd.getahead.dwr.*;

/**
 * DowryContext enables access to the Dowry-related
 * objects.
 *
 */
public class DowryContext
{
	/**
	 * Gets the datatype manager.
	 *
	 * @return the current datatype manager
	 *
	 */
	public static DatatypeManager getDatatypeManager()
	{
		DatatypeManager datatypeManager = null;

		Container container = getContainer();
		if (container != null)
		{
			datatypeManager = (DatatypeManager)
			    container.getBean(DatatypeManager.class.getName());
		}

		return datatypeManager;
	}

	/**
	 * Gets the Dowry service.
	 *
	 * @return the current Dowry service
	 *
	 */
	public static DowryService getDowryService()
	{
		DowryService service = null;

		Container container = getContainer();
		if (container != null)
		{
			service = (DowryService)
			    container.getBean(DowryService.class.getName());
		}

		return service;
	}

	/**
	 * Gets the entity mapper.
	 *
	 * @return the current entity mapper
	 *
	 */
	public static EntityMapper getEntityMapper()
	{
		EntityMapper entityMapper = null;

		Container container = getContainer();
		if (container != null)
		{
			entityMapper = (EntityMapper)
			    container.getBean(EntityMapper.class.getName());
		}

		return entityMapper;
	}

	/**
	 * Gets the interceptor.
	 *
	 * @return the current interceptor
	 *
	 */
	public static Interceptor getInterceptor()
	{
		Interceptor interceptor = null;

		Container container = getContainer();
		if (container != null)
		{
			interceptor = (Interceptor)
			    container.getBean(Interceptor.class.getName());
		}

		return interceptor;
	}

	/**
	 * Gets DWR's IoC container.
	 *
	 * @return the current container
	 *
	 */
	protected static Container getContainer()
	{
		Container container = null;

		WebContext ctx = WebContextFactory.get();
		if (ctx != null)
		{
			container = ctx.getContainer();
		}

		return container;
	}
}