$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.BooleanType");
$import("dowry.test.Test");

$class("BooleanTypeTest").$extends("Test").$as(
{
	testToDatatype : function()
	{
		var dt = new dowry.datatype.BooleanType();
		this.assertNull(dt.toDatatype("bogus"));
		this.assertEqual(dt.toDatatype(true), true);
		this.assertEqual(dt.toDatatype(false), false);
		this.assertEqual(dt.toDatatype("true"), true);
		this.assertEqual(dt.toDatatype("false"), false);
		this.assertNull(dt.toDatatype(1));
		this.assertNull(dt.toDatatype(0));
		this.assertNull(dt.toDatatype(""));
		this.assertNull(dt.toDatatype(null));
	},

	testToFormattedString : function()
	{
		var dt = new dowry.datatype.BooleanType();
		this.assertEqual(dt.toFormattedString(true), "true");
		this.assertEqual(dt.toFormattedString(false), "false");
		this.assertEqual(dt.toFormattedString("true"), "true");
		this.assertEqual(dt.toFormattedString("false"), "false");
		this.assertNull(dt.toFormattedString(1));
		this.assertNull(dt.toFormattedString(0));
		this.assertNull(dt.toFormattedString(""));
		this.assertNull(dt.toFormattedString(null));

      	this.assertEqual(dt.toConfiguration().$class, "dowry.datatype.BooleanType");
      	this.assertEqual(dt.toConfiguration().validChars, "truefalse");
      	this.assertNotEqual(dt.toConfiguration().validChars.indexOf("true"), -1);
      	this.assertNotEqual(dt.toConfiguration().validChars.indexOf("false"), -1);
      	this.assertEqual(dt.toConfiguration().maxLength, "FALSE".length);
	},

	testValidate : function()
	{
		var dt = new dowry.datatype.BooleanType();
		this.assertEqual(dt.required, false);
		this.assertEqual(dt.validate("bogus"), dt.ERROR_NOT_A_BOOLEAN);
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertNull(dt.validate("true"));
		this.assertNull(dt.validate("false"));
		this.assertEqual(dt.validate(1), dt.ERROR_NOT_A_BOOLEAN);
		this.assertEqual(dt.validate(0), dt.ERROR_NOT_A_BOOLEAN);
		this.assertEqual(dt.validate(""), dt.ERROR_NOT_A_BOOLEAN);
		this.assertNull(dt.validate(null));

		var dt = new dowry.datatype.BooleanType();
		dt.required = true;
		this.assertEqual(dt.required, true);
		this.assertEqual(dt.validate("bogus"), dt.ERROR_NOT_A_BOOLEAN);
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertNull(dt.validate("true"));
		this.assertNull(dt.validate("false"));
		this.assertEqual(dt.validate(1), dt.ERROR_NOT_A_BOOLEAN);
		this.assertEqual(dt.validate(0), dt.ERROR_NOT_A_BOOLEAN);
		this.assertEqual(dt.validate(""), dt.ERROR_NOT_A_BOOLEAN);
		this.assertEqual(dt.validate(null), dt.ERROR_REQUIRED);
	}
});