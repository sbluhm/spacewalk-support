package dowry;

import java.util.*;

/**
 * The Datatype interface serves as an intermediary between
 * Javascript and Java types, particularly in regard to
 * remote validation.
 *
 */
public interface Datatype
{
	/**
	 * Gets the name of the Javascript class that serves
	 * as the client-side equivalent to this Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass();

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName);

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c);

	/**
	 * Validates the specified configuration, according to
	 * the rules of this datatype.  The Datatype should
	 * receive all relevant information via this map,
	 * including the value to validate.  It returns a
	 * String with the appropriate validation message (or
	 * null if validation passes).
	 *
	 * <p>
	 * The Datatype should be prepared for any/all map
	 * values to be Strings, although it should not depend
	 * upon this.
	 * </p>
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      the string validation error message,
	 *              if the validation fails; null otherwise
	 *
	 */
	public String validate(Map cfg);
}