package dowry.impl;

import dowry.*;
import uk.ltd.getahead.dwr.*;

/**
 * DefaultJavascript implements the Javascript interface
 * using the DWR ConverterManager to handle our
 * Java-to-Javascript translation.
 *
 */
public class DefaultJavascript implements Javascript
{
	private ConverterManager converterMgr = null;

	/**
	 * Returns the converter manager.
	 *
	 * @return  the converter manager
	 *
	 */
	public ConverterManager getConverterManager()
	{
		return converterMgr;
	}

	/**
	 * Sets the converter manager.
	 *
	 * @param converterMgr  the converter manager
	 *
	 */
	public void setConverterManager(ConverterManager converterMgr)
	{
		this.converterMgr = converterMgr;
	}

	/**
	 * Outputs the specified Java object as a Javascript
	 * variable assignment.  This version of the method
	 * will always create a new variable.
	 *
	 * @param id      the variable name the object should be
	 *                assigned to
	 *
	 * @param var     the Java object to be expressed as a
	 *                Javascript variable
	 *
	 * @return        string containing the Javascript code
	 *                to perform the variable assignments
	 */
	public String var(String id, Object var)
	{
		return var(id, var, true);
	}

	/**
	 * Outputs the specified Java object as a Javascript
	 * variable assignment.  This version will create a
	 * new variable or simply make an assignment to an
	 * existing variable name, depending on the value of the
	 * newVar parameter.
	 *
	 * @param id      the variable name the object should be
	 *                assigned to
	 *
	 * @param var     the Java object to be expressed as a
	 *                Javascript variable
	 *
	 * @param newVar  if this is true, this will create a
	 *                new variable with the assigned id;
	 *                otherwise, it will just assign to the
	 *                existing variable
	 *
	 * @return        string containing the Javascript code
	 *                to perform the variable assignments
	 */
	public String var(String id, Object var, boolean newVar)
	{
		StringBuffer sb = new StringBuffer();

		if (id != null)
		{
			if (newVar)
			{
				sb.append("var ");
			}

			sb.append(id + " = (function() {");

			try
			{
				ConverterManager coverterMgr = getConverterManager();
				if (converterMgr != null)
				{
					OutboundContext outCtx = new OutboundContext();

					OutboundVariable outVar =
					    converterMgr.convertOutbound(var, outCtx);

					sb.append(outVar.getInitCode());
					sb.append("return " +outVar.getAssignCode()+";");
				}
			}
			catch(Exception ex)
			{
			}

			sb.append("})();");
		}

		return sb.toString();
	}
}