$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.TextAreaWidget");
$import("dowry.test.Test");

$class("TextAreaWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.TextAreaWidget();
	}
});