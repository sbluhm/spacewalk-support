package dowry;

import java.util.*;

/**
 * EntityMapper handles the mapping of some source of entity
 * information (eg Hibernate configuration) into a mapping
 * format suitable for Dowry.
 *
 */
public interface EntityMapper
{
	/**
	 * Augments the entity mapping based on the specified
	 * attribute value.  This will override any existing
	 * value for this attribute.
	 *
	 * @param entity     the string name of the entity
	 *
	 * @param property   the string name of the property
	 *
	 * @param attribute  the string name of the attribute
	 *
	 * @param value      the attribute value to be included
	 *
	 */
	public void addAttribute(String entity,
	                         String property,
	                         String attribute,
	                         Object value);

	/**
	 * Returns the classes for the mapped entities.
	 *
	 * @return  a set of class objects representing the
	 *          mapped entities
	 *
	 */
	public Set getClasses();

	/**
	 * Returns a mapping of Dowry entities.  The format
	 * of this map is:
	 *
	 * <pre>
	 * Map&lt;String entity,
	 *     Map&lt;String property,
	 *         Map&lt;String attribute, Object value&gt;&gt;&gt;
	 * </pre>
	 *
	 * @return  a map representing the Dowry entities
	 *
	 */
	public Map getEntityMapping();

	/**
	 * Returns the string names for the mapped entities.
	 *
	 * @return  a set of the the string names of the mapped
	 *          entities
	 *
	 */
	public Set getNames();

	/**
	 * Returns a set of all the string Dowry types
	 * referenced in this mapping.  This includes both the
	 * types of all mapped properties, as well as the types
	 * of the entities themselves.
	 *
	 * @return a set of string names of the Dowry types
	 *         represented in the mapping
	 *
	 */
	public Set getTypes();
}