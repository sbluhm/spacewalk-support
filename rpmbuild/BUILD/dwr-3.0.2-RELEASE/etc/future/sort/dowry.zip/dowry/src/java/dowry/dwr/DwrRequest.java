package dowry.dwr;

import javax.servlet.http.*;

/**
 * DwrRequest is a wrapper to the actual servlet request,
 * allowing us to modify the request's path info value.
 *
 */
public class DwrRequest extends HttpServletRequestWrapper
{
	private boolean override = false;
	private String  pathInfo = null;

	/**
	 * Construct a wrapper to the provided servlet request
	 * instance.
	 *
	 * @param req  the servlet request to be wrapped
	 *
	 */
	public DwrRequest(HttpServletRequest req)
	{
		super(req);
	}

	/**
	 * Returns any extra path information associated with
	 * the URL the client sent when it made this request.
	 * The extra path information follows the servlet path
	 * but precedes the query string and will start with a
	 * "/" character.
	 *
	 * This method returns null if there was no extra path
	 * information.
	 *
	 * Same as the value of the CGI variable PATH_INFO.
	 *
	 * @return   a String, decoded by the web container,
	 *           specifying extra path information that
	 *           comes after the servlet path but before
	 *           the query string in the request URL; or
	 *           null if the URL does not have any extra
	 *           path information
	 *
	 */
	public String getPathInfo()
	{
		String s = null;

		if (override)
		{
			s = pathInfo;
		}
		else
		{
			s = super.getPathInfo();
		}

		return s;
	}

	/**
	 * Modifies the extra path information for this request
	 * to the path info specified.
	 *
	 * @param s  a string representing the path information
	 *           to be associated with this request
	 *
	 */
	public void setPathInfo(String s)
	{
		pathInfo = s;
		override = true;
	}
}