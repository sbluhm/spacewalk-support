Dowry.handlers["/Player.html"]          = "demo.PlayerHandler";
Dowry.handlers["/PlayerList.html"]      = "demo.PlayerListHandler";
Dowry.handlers["/Team.html"]            = "demo.TeamHandler";
Dowry.handlers["/TeamList.html"]        = "demo.TeamListHandler";

Dowry.widgets["LinkTableWidget"]        = "demo.LinkTableWidget";

Dowry.datatypes["jersey_number"]        = "demo.JerseyNumberType";