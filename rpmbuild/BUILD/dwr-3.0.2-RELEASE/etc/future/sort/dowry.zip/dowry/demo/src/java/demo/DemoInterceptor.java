package demo;

import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.Transaction;
import dowry.*;

public class DemoInterceptor implements Interceptor
{
    private static final String TX = "hibernate.tx";

	public void onInit(ServletConfig cfg)
	{
	}

	public void onInvoke(HttpServletRequest req, HttpServletResponse res)
	{
        Persistence.open();
        Transaction tx = Persistence.begin();
        req.setAttribute(TX, tx);
	}

	public void onSuccess(HttpServletRequest req, HttpServletResponse res)
	{
        Transaction tx = (Transaction) req.getAttribute(TX);
        req.removeAttribute(TX);
        Persistence.commit(tx);
        Persistence.close();
	}

	public void onError(HttpServletRequest req, HttpServletResponse res)
	{
        Transaction tx = (Transaction) req.getAttribute(TX);
        req.removeAttribute(TX);
        Persistence.rollback(tx);
        Persistence.close();
	}

	public void onDestroy()
	{
	}
}