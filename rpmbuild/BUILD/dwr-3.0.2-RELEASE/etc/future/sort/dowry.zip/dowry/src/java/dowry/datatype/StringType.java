package dowry.datatype;

import java.util.*;
import dowry.*;

/**
 * Object representation of a string datatype.
 *
 */
public class StringType extends AbstractType
{
    /**
     * Constant for the error message when validation finds
     * a value longer than the maximum length.
     *
     */
	public static final String ERROR_TOO_LONG = Messages.get("ERROR_TOO_LONG");

	/**
	 * Constant for the configuration key containing the
	 * datatype's <code>length</code> property indicating
	 * the maximum length of this string.
	 *
	 */
	public static final String LENGTH = "length";

	/**
	 * Constant for the datatype's name.
	 *
	 */
	public static final String NAME = Messages.get("string");

	/**
	 * Gets the name of the Javascript class that serves
	 * as the client side equivalent to this Java Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass()
	{
		return StringType.class.getName();
	}

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName)
	{
		return (typeName != null && typeName.equals(NAME));
	}

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * <p>
	 * This implementation returns 'string'.
	 * </p>
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c)
	{
		return NAME;
	}

	/**
	 * Validates that:
	 *
	 * <ol>
	 *  <li>  the value is provided, if required as
	 *        specified by map key <code>required</code>
	 *  </li>
	 *  <li>  the value does not exceed the length specified
	 *        by map key <code>length</code>
	 *  </li>
	 * </ol>
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      the string validation error message,
	 *              if the validation fails; null otherwise
	 *
	 */
	public String validate(Map cfg)
	{
		String msg = super.validate(cfg);

		String val = getString(cfg, VALUE);
		Integer len = getInteger(cfg, LENGTH);

		if (msg == null && val != null && len != null)
		{
			if (val.length() > len.intValue())
			{
				msg = ERROR_TOO_LONG;
			}
		}

		return msg;
	}
}