package demo;

import java.io.*;
import java.sql.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import dowry.hibernate.*;

public class DemoProvider implements HibernateProvider
{
	public DemoProvider()
	{
		Configuration cfg = new Configuration().
		                    setNamingStrategy(ImprovedNamingStrategy.INSTANCE).
		                    configure();

		Persistence.init(cfg);

		populateDb();
	}

	public Configuration getConfiguration()
	{
		return Persistence.getConfiguration();
	}

	public SessionFactory getSessionFactory()
	{
		return Persistence.getSessionFactory();
	}

	private void populateDb()
	{
		// initialize persitence
		Persistence.open();

		// get the connection
		Session sess = Persistence.getSession();
		Connection conn = sess.connection();

		// get a file handle to our sql script
        InputStream raw = getClass().
                          getResourceAsStream("/demo.sql");

		Statement stmt = null;

        if (raw != null)
        {
	        BufferedReader in =
	           new BufferedReader(new InputStreamReader(raw));

			// loop through each line of our file
	        while (true)
	        {
				try
				{
		            String line = in.readLine();
		            if (line == null)
		            {
		                break;
		            }

					// perform the insert
					if (stmt == null)
					{
						stmt = conn.createStatement();
					}
					stmt.executeUpdate(line);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
	        }
		}

		// cleanup resources
		try
		{
			raw.close();
			conn.commit();
			stmt.close();
			Persistence.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}