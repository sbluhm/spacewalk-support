$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.AutocompleterWidget");
$import("dowry.test.Test");

$class("AutocompleterWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.AutocompleterWidget();
	}
});