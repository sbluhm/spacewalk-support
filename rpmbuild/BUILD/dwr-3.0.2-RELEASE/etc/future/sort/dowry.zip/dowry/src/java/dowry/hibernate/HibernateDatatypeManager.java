package dowry.hibernate;

import java.util.*;
import dowry.*;
import dowry.impl.*;

/**
 * HibernateDatatypeManager manages the mapping of classes
 * to Hibernate datatypes.
 *
 */
public class HibernateDatatypeManager extends DefaultDatatypeManager
{
	/**
	 * Constructs a new instance of HibernateDatatypeManager
	 * and registers the built-in Hibernate datatypes.
	 *
	 */
	public HibernateDatatypeManager()
	{
		this(true);
	}

	/**
	 * Constructs a new instance of HibernateDatatypeManager
	 * and registers the built-in Hibernate datatypes (if
	 * regsiter defaults is set to true).  This constructor
	 * will not be called under normal circumstances-- it
	 * is only provided for those who wish to extend
	 * the datatype manager and provide their own defaults.
	 *
	 * @param registerDefaults  when true, registers the
	 *                          built-in Hibernate datatypes
	 *
	 */
	protected HibernateDatatypeManager(boolean registerDefaults)
	{
		if (registerDefaults)
		{
			addDatatype(Collection.class, new ArrayType());
			addDatatype(Boolean.class,    new BooleanType());
			addDatatype(Date.class,       new DateType());
			addDatatype(String.class,     new StringType());
			addDatatype(Number.class,     new NumberType());
			addDatatype(Object.class,     new ObjectType());
		}
	}

	/**
	 * Registers a datatype.  This datatype will not be
	 * associated to any specific Java class, and thus
	 * will not be returned via <code>getDatatype()</code>.
	 * However, it will be available via
	 * <code>getDatatypes()</code>, and possibly via
	 * <code>getDatatypeByType()</code>.
	 *
	 * <p>
	 * If the datatype does not extend HibernateType, then
	 * the call will be ignored.
	 * </p>
	 *
	 * @param  datatype  the datatype to be registered
	 *
	 */
	public void addDatatype(Datatype datatype)
	{
		if (datatype != null &&
		    datatype instanceof HibernateType)
		{
			super.addDatatype(datatype);
		}
	}

	/**
	 * Register a datatype to handle the specified class.
	 * This datatype will be used to handle any object that
	 * is an instance of this class, or any objects
	 * that extends or implements the specified class
	 * (such that the closest match wins).
	 *
	 * <p>
	 * If the datatype does not extend HibernateType, then
	 * the call will be ignored.
	 * </p>
	 *
	 * @param  c         the class to register this datatype
	 *                   to
	 *
	 * @param  datatype  the datatype to be registered
	 *
	 */
	public void addDatatype(Class c, Datatype datatype)
	{
		if (c != null &&
		    datatype != null &&
		    datatype instanceof HibernateType)
		{
			super.addDatatype(c, datatype);
		}
	}
}