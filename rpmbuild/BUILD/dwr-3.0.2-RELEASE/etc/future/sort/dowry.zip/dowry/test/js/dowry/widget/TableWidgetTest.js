$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.TableWidget");
$import("dowry.test.Test");

$class("TableWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.TableWidget();
	}
});