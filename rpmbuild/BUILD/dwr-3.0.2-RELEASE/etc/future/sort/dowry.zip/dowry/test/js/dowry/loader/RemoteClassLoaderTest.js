$package("dowry.loader");

$import("dowry.loader.ClassLoader");
$import("dowry.loader.RemoteClassLoader");
$import("dowry.test.Test");

$class("RemoteClassLoaderTest").$extends("Test").$as(
{
	setup : function()
	{
		DWREngine =
		{
			XMLHttpRequest: true
		};

		var parentLoader = new dowry.loader.ClassLoader();

		this.mockService =
		{
			loadJsCalled : false,

			loadJs : function(name, meta)
			{
				arguments.callee.called = true;
				var js = "$class('"+name+"').$as({});";
				meta.callback.call(null, js);
			}
		};

		this.loader = new dowry.loader.RemoteClassLoader(
		    parentLoader, this.mockService);
	},

	testLoadClass : function()
	{
		this.assertNotNull(this.loader.loadClass("dowry.test.Test"));
		this.assertNotNull(dowry.test.Test);
		this.assertNotEqual(this.mockService.loadJs.called, true);

		this.assertNotNull(this.loader.loadClass("org.example.Foo"));
		this.assertNotNull(org.example.Foo);
		this.assertEqual(this.mockService.loadJs.called, true);
	},

	teardown : function()
	{
		this.loader = null;
		this.mockService = null;
	}
});