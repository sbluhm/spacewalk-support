$package("dowry.util");

$import("dowry.util.CssUtils");
$import("dowry.test.Test");

$class("CssUtilsTest").$extends("Test").$as(
{
	setup : function()
	{
		this.css = new dowry.util.CssUtils();
		this.css.usePrefix = false;

		this.css2 = new dowry.util.CssUtils();
		this.css2.usePrefix = true;
	},

	testAddClassName : function()
	{
		this.createEle(null);
		this.assertEqual(this.css.getClassNames("test").length, 0);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle(null);
		this.assertEqual(this.css.getClassNames("test").length, 0);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css2.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 1);

		this.createEle("bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css2.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 1);

		this.createEle("dowry:bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 1);
		this.css.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 1);

		this.createEle("dowry:bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 1);
		this.css2.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 2);

		this.createEle("bubba wonka");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 3);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("bubba wonka");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
		this.css2.addClassName("test", "blah");
		this.assertEqual(this.css.getClassNames("test").length, 3);
		this.assertEqual(this.css2.getClassNames("test").length, 1);
	},

	testGetClassNames : function()
	{
		this.createEle("foo bar baz");
		var classNames = this.css.getClassNames("test");
		this.assertEqual(classNames.length, 3);
		this.assertEqual(classNames[0], "foo");
		this.assertEqual(classNames[1], "bar");
		this.assertEqual(classNames[2], "baz");

		this.createEle("foo bar baz");
		var classNames = this.css2.getClassNames("test");
		this.assertEqual(classNames.length, 0);

		this.createEle("dowry:foo dowry:bar dowry:baz");
		var classNames = this.css.getClassNames("test");
		this.assertEqual(classNames.length, 3);
		this.assertEqual(classNames[0], "dowry:foo");
		this.assertEqual(classNames[1], "dowry:bar");
		this.assertEqual(classNames[2], "dowry:baz");

		this.createEle("dowry:foo dowry:bar dowry:baz");
		var classNames = this.css2.getClassNames("test");
		this.assertEqual(classNames.length, 3);
		this.assertEqual(classNames[0], "foo");
		this.assertEqual(classNames[1], "bar");
		this.assertEqual(classNames[2], "baz");

		this.createEle("dowry:foo dowry:bar baz");
		var classNames = this.css.getClassNames("test");
		this.assertEqual(classNames.length, 3);
		this.assertEqual(classNames[0], "dowry:foo");
		this.assertEqual(classNames[1], "dowry:bar");
		this.assertEqual(classNames[2], "baz");

		this.createEle("dowry:foo dowry:bar baz");
		var classNames = this.css2.getClassNames("test");
		this.assertEqual(classNames.length, 2);
		this.assertEqual(classNames[0], "foo");
		this.assertEqual(classNames[1], "bar");

		this.createEle(null);
		var classNames = this.css.getClassNames("test");
		this.assertEqual(classNames.length, 0);

		this.createEle(null);
		var classNames = this.css2.getClassNames("test");
		this.assertEqual(classNames.length, 0);

		this.createEle("");
		var classNames = this.css.getClassNames("test");
		this.assertEqual(classNames.length, 0);

		this.createEle("");
		var classNames = this.css2.getClassNames("test");
		this.assertEqual(classNames.length, 0);
	},

	testGetElementsByClassName : function()
	{
		this.createEle("foo bar baz", "test1");
		this.createEle("dowry:foo dowry:bar dowry:baz", "test2");
		this.createEle("dowry:foo dowry:bar baz", "test3");
		this.createEle(null, "test4");
		this.createEle("", "test5");
		this.createEle("dowry:", "test6");
		this.createEle("bubba", "test7");

		var eles = this.css.getElementsByClassName("foo");
		this.assertEqual(eles.length, 1);
		this.assertEqual(eles[0].id, "test1");

		var eles = this.css2.getElementsByClassName("foo");
		this.assertEqual(eles.length, 2);
		this.assertEqual(eles[0].id, "test2");
		this.assertEqual(eles[1].id, "test3");

		var eles = this.css.getElementsByClassName("baz");
		this.assertEqual(eles.length, 2);
		this.assertEqual(eles[0].id, "test1");
		this.assertEqual(eles[1].id, "test3");

		var eles = this.css2.getElementsByClassName("baz");
		this.assertEqual(eles.length, 1);
		this.assertEqual(eles[0].id, "test2");

		var eles = this.css.getElementsByClassName(null);
		this.assertEqual(eles.length, 0);

		var eles = this.css2.getElementsByClassName(null);
		this.assertEqual(eles.length, 0);

		var eles = this.css.getElementsByClassName("");
		this.assertEqual(eles.length, 0);

		var eles = this.css2.getElementsByClassName("");
		this.assertEqual(eles.length, 0);

		var eles = this.css.getElementsByClassName("dowry:");
		this.assertEqual(eles.length, 1);
		this.assertEqual(eles[0].id, "test6");

		var eles = this.css2.getElementsByClassName("dowry:");
		this.assertEqual(eles.length, 0);

		this.removeEle("test1");
		this.removeEle("test2");
		this.removeEle("test3");
		this.removeEle("test4");
		this.removeEle("test5");
		this.removeEle("test6");
		this.removeEle("test7");
	},

	testHasClassName : function()
	{
		this.createEle("foo bar baz");
		this.assertEqual(this.css.hasClassName("test", "foo"), true);
		this.assertEqual(this.css.hasClassName("test", "bar"), true);
		this.assertEqual(this.css.hasClassName("test", "baz"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dummy"), false);

		this.createEle("foo bar baz");
		this.assertEqual(this.css2.hasClassName("test", "foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dummy"), false);

		this.createEle("dowry:foo dowry:bar dowry:baz");
		this.assertEqual(this.css.hasClassName("test", "foo"), false);
		this.assertEqual(this.css.hasClassName("test", "bar"), false);
		this.assertEqual(this.css.hasClassName("test", "baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:foo"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:bar"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:baz"), true);
		this.assertEqual(this.css.hasClassName("test", "dummy"), false);

		this.createEle("dowry:foo dowry:bar dowry:baz");
		this.assertEqual(this.css2.hasClassName("test", "foo"), true);
		this.assertEqual(this.css2.hasClassName("test", "bar"), true);
		this.assertEqual(this.css2.hasClassName("test", "baz"), true);
		this.assertEqual(this.css2.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dummy"), false);

		this.createEle("dowry:foo dowry:bar baz");
		this.assertEqual(this.css.hasClassName("test", "foo"), false);
		this.assertEqual(this.css.hasClassName("test", "bar"), false);
		this.assertEqual(this.css.hasClassName("test", "baz"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:foo"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:bar"), true);
		this.assertEqual(this.css.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dummy"), false);

		this.createEle("dowry:foo dowry:bar baz");
		this.assertEqual(this.css2.hasClassName("test", "foo"), true);
		this.assertEqual(this.css2.hasClassName("test", "bar"), true);
		this.assertEqual(this.css2.hasClassName("test", "baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dummy"), false);

		this.createEle(null);
		this.assertEqual(this.css.hasClassName("test", "foo"), false);
		this.assertEqual(this.css.hasClassName("test", "bar"), false);
		this.assertEqual(this.css.hasClassName("test", "baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dummy"), false);

		this.createEle(null);
		this.assertEqual(this.css2.hasClassName("test", "foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dummy"), false);

		this.createEle("");
		this.assertEqual(this.css.hasClassName("test", "foo"), false);
		this.assertEqual(this.css.hasClassName("test", "bar"), false);
		this.assertEqual(this.css.hasClassName("test", "baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css.hasClassName("test", "dummy"), false);

		this.createEle("");
		this.assertEqual(this.css2.hasClassName("test", "foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:foo"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:bar"), false);
		this.assertEqual(this.css2.hasClassName("test", "dowry:baz"), false);
		this.assertEqual(this.css2.hasClassName("test", "dummy"), false);
	},

	testRemoveClassName : function()
	{
		this.createEle("bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
 		this.css2.removeClassName("test", "bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
 		this.css.removeClassName("test", "bubba");
		this.assertEqual(this.css.getClassNames("test").length, 0);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("dowry:bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 1);
 		this.css2.removeClassName("test", "bubba");
		this.assertEqual(this.css.getClassNames("test").length, 0);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("bubba wonka");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
 		this.css2.removeClassName("test", "bubba");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);

		this.createEle("bubba wonka");
		this.assertEqual(this.css.getClassNames("test").length, 2);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
 		this.css.removeClassName("test", "bubba");
		this.assertEqual(this.css.getClassNames("test").length, 1);
		this.assertEqual(this.css2.getClassNames("test").length, 0);
	},

	teardown : function()
	{
		this.removeEle();
		this.css = null;
		this.css2 = null;
	},

	createEle : function(className, id)
	{
		this.removeEle(id);
		var ele = document.createElement("span");
		ele.id = id || "test";

		if (className)
		{
			ele.className = className;
		}

		document.body.appendChild(ele);
	},

	removeEle : function(id)
	{
		var id = id || "test";
		ele = document.getElementById(id);
		if (ele && ele.parentNode)
		{
			ele.parentNode.removeChild(ele);
		}
	}
});