package dowry.datatype;

import java.util.*;
import dowry.*;

/**
 * Object representation of a boolean datatype.
 *
 */
public class BooleanType extends AbstractType
{
	/**
	 * Constant for the error message when validation finds
	 * value other than true or false.
	 *
	 */
	public static final String ERROR_NOT_A_BOOLEAN =
	    Messages.get("ERROR_NOT_A_BOOLEAN");

	/**
	 * Constant for the datatype's name.
	 *
	 */
	public static final String NAME = Messages.get("boolean");

	/**
	 * Gets the name of the Javascript class that serves
	 * as the client side equivalent to this Java Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass()
	{
		return BooleanType.class.getName();
	}

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName)
	{
		return (typeName != null && typeName.equals(NAME));
	}

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * <p>
	 * This implementation returns 'boolean'.
	 * </p>
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c)
	{
		return NAME;
	}

	/**
	 * Validates that:
	 *
	 * <ol>
	 *  <li>  the value is provided, if required as
	 *        specified by map key <code>required</code>
	 *  </li>
	 *  <li>  the value represents <code>true</code> or
	 *        <code>false</code>
	 *  </li>
	 * </ol>
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      the string validation error message,
	 *              if the validation fails; null otherwise
	 *
	 */
	public String validate(Map cfg)
	{
		String msg = super.validate(cfg);

		Object val = cfg.get(VALUE);
		if (msg == null && val != null)
		{
			// compare to the literal string to
			// avoid unwanted type coersion
			Boolean b = getBoolean(cfg, VALUE);
			if (b == null)
			{
				msg = ERROR_NOT_A_BOOLEAN;
			}
		}

		return msg;
	}
}