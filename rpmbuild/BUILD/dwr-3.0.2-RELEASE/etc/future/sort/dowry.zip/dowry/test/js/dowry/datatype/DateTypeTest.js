$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.DateType");
$import("dowry.test.Test");

$class("DateTypeTest").$extends("Test").$as(
{
	testCompare : function()
	{
		var dt = new dowry.datatype.DateType();
		this.assertEqual(dt.compare(new Date(2006, 0, 1), new Date(2006, 0, 1)), 0);
		this.assertEqual(dt.compare(new Date(2006, 11, 13), new Date(2006, 11, 13)), 0);
		this.assertEqual(dt.compare(new Date(2006, 11, 13), new Date(2006, 11, 14)), -1);
      	this.assertEqual(dt.compare(new Date(2006, 11, 15), new Date(2006, 11, 14)), 1);
      	this.assertEqual(dt.compare(new Date(2007, 0, 15), new Date(2006, 11, 14)), 1);
		this.assertEqual(dt.compare(new Date(1969, 0, 15), new Date(1971, 11, 14)), -1);
		this.assertEqual(dt.compare(new Date(1968, 0, 15), new Date(1966, 11, 14)), 1);
      	this.assertEqual(dt.compare(new Date(2006, 11, 21), new Date(2007, 0, 1)), -1);
	},

	testParseDate : function()
	{
		var dt = new dowry.datatype.DateType();
		dt.format = "%mon %d, %yyyy";

      	this.assertEqual(dt.compare(dt.parseDate("Jan 01, 2006"), new Date(2006, 0, 1)), 0);
      	this.assertEqual(dt.compare(dt.parseDate("Dec 12, 2006"), new Date(2006, 11, 12)), 0);
      	this.assertEqual(dt.compare(dt.parseDate("Jul 8, 2005"), new Date(2005, 6, 8)), 0);
      	this.assertNull(dt.parseDate("This is not a date."));
      	this.assertNull(dt.parseDate("121222"));
	},

	testToFormattedString : function()
	{
		var dt = new dowry.datatype.DateType();
		dt.format = "%mon %d, %yyyy";

      	this.assertNull(dt.toFormattedString(null));
      	this.assertNull(dt.toFormattedString("Sep 31, 1912"));
      	this.assertNull(dt.toFormattedString("January 31, 1912"));
      	this.assertNull(dt.toFormattedString("cat"));

      	this.assertNotNull(dt.toFormattedString(123412221222));
      	this.assertNotNull(dt.toFormattedString(12341222));
      	this.assertNotNull(dt.toFormattedString(99));

      	this.assertEqual(dt.toFormattedString("Jan 1, 1988"), "Jan 1, 1988");
      	this.assertEqual(dt.toFormattedString("Jan 31, 1988"), "Jan 31, 1988");
      	this.assertEqual(dt.toFormattedString("Sep 30, 1912"), "Sep 30, 1912");
      	this.assertEqual(dt.toFormattedString("Dec 25, 2020"), "Dec 25, 2020");

      	this.assertEqual(dt.toFormattedString(new Date(1988, 0, 1)), "Jan 1, 1988");
      	this.assertEqual(dt.toFormattedString(new Date(1988, 0, 31)), "Jan 31, 1988");
      	this.assertEqual(dt.toFormattedString(new Date(1912, 8, 30)), "Sep 30, 1912");
      	this.assertEqual(dt.toFormattedString(new Date(2020, 11, 25)), "Dec 25, 2020");
	},

	testToDatatype : function()
	{
		var dt = new dowry.datatype.DateType();
		dt.format = "%mon %d, %yyyy";

      	this.assertNull(dt.toDatatype(null));
      	this.assertNull(dt.toDatatype(123));
      	this.assertNull(dt.toDatatype("cat"));
      	this.assertNull(dt.toDatatype("July 8, 2005"));
      	this.assertEqual(dt.compare(dt.toDatatype(new Date(2005, 6, 8)), new Date(2005, 6, 8)), 0);
      	this.assertEqual(dt.compare(dt.toDatatype("Jul 8, 2005"), new Date(2005, 6, 8)), 0);
	}
/*
		dt.format = dt.FORMAT_SHORT;
      	this.assertNull(dt.validate(new Date("Sep 18, 2009")));
      	this.assertEqual(dt.compare(dt.toDatatype(new Date("Sep 18, 2009")), new Date("Sep 18, 2009")), 0);
      	this.assertNull(dt.validate(new Date("Jan 31, 1998")));
      	this.assertEqual(dt.compare(dt.toDatatype(new Date("Jan 31, 1998")), new Date("Jan 31, 1998")), 0);
      	this.assertNull(dt.validate(new Date("Feb 28, 2006")));
      	this.assertEqual(dt.compare(dt.toDatatype(new Date("Feb 28, 2006")), new Date("Feb 28, 2006")), 0);
      	this.assertNull(dt.validate(new Date("12/12/12")));
      	this.assertEqual(dt.compare(dt.toDatatype(new Date("12/12/12")), new Date("12/12/12")), 0);
      	this.assertNull(dt.validate("12.12.99"));
      	this.assertEqual(dt.toDatatype("12.12.99").getTime(), new Date("12/12/99").getTime());
      	this.assertNull(dt.validate("01.01.01"));
      	this.assertEqual(dt.toDatatype("01.01.01").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("01.01.01").getDate(), 1);
      	this.assertEqual(dt.toDatatype("01.01.01").getFullYear(), 2001);
      	this.assertEqual(dt.toDatatype("01.01.26").getDate(), 1);
      	this.assertEqual(dt.toDatatype("01.01.26").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("01.01.26").getFullYear(), 2026);
      	this.assertEqual(dt.toDatatype("01.01.53").getDate(), 1);
      	this.assertEqual(dt.toDatatype("01.01.53").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("01.01.53").getFullYear(), 1953);
      	this.assertEqual(dt.toDatatype("02.11.54").getDate(), 11);
      	this.assertEqual(dt.toDatatype("02.11.54").getMonth(), 1);
      	this.assertEqual(dt.toDatatype("02.11.54").getFullYear(), 1954);
      	this.assertNull(dt.validate("02.28.98"));
      	this.assertEqual(dt.toDatatype("02.28.98").getTime(), new Date("02/28/98").getTime());
      	this.assertNull(dt.validate("02.28.00"));
      	this.assertEqual(dt.toDatatype("02.28.00").getDate(), 28);
      	this.assertEqual(dt.toDatatype("02.28.00").getMonth(), 1);
      	this.assertEqual(dt.toDatatype("02.28.00").getFullYear(), 2000);
      	this.assertNotNull(dt.validate("02.28.2006"));
      	this.assertNotNull(dt.validate("13.12.99"));
      	this.assertNull(dt.toDatatype("13.12.99"));
      	this.assertNotNull(dt.validate("01.32.99"));
      	this.assertNull(dt.toDatatype("01.32.99"));
      	this.assertNotNull(dt.validate("13.32.99"));
      	this.assertNull(dt.toDatatype("13.32.99"));
      	this.assertNotNull(dt.validate("cat"));
      	this.assertNull(dt.toDatatype("cat"));
      	this.assertNotNull(dt.validate("01/01/2006"));
      	this.assertNull(dt.toDatatype("01/01/2006"));
      	this.assertNull(dt.toFormattedString(null));
      	this.assertNull(dt.toFormattedString("February 13, 2006"));
      	this.assertNotNull(dt.toFormattedString(123412221222));
      	this.assertNotNull(dt.toFormattedString(12341222));
      	this.assertNotNull(dt.toFormattedString(99));
      	this.assertNull(dt.toFormattedString("cat"));
      	//TODO:  Following 6 tests fail.
      	// With dt.format = dt.FORMAT_SHORT, toFormattedString returns a four digit year.
       	//	i.e. "dt.toFormattedString("02.28.98")" actually returns "2.28.1998".
      	this.assertEqual(dt.toFormattedString("02.28.98"), "2.28.98");
      	this.assertEqual(dt.toFormattedString("06.07.06"), "6.7.06");
      	this.assertEqual(dt.toFormattedString(new Date("01/01/2002")), "1.1.02");
      	this.assertEqual(dt.toFormattedString(new Date("09/21/2002")), "9.21.02");
      	this.assertEqual(dt.toFormattedString(new Date("09/21/2002").getTime()), "9.21.02");
      	this.assertEqual(dt.toFormattedString(new Date("11/29/1998").getTime()), "11.29.98");

		dt.format = dt.FORMAT_DEFAULT;
      	this.assertNull(dt.validate(new Date("Sep 18, 2009")));
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getDate(), 18);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getMonth(), 8);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getFullYear(), 2009);
      	this.assertNull(dt.validate(new Date("Jan 31, 1998")));
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getDate(), 31);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getMonth(), 0);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getFullYear(), 1998);
      	this.assertNull(dt.validate(new Date("Feb 28, 2006")));
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getDate(), 28);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getMonth(), 1);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getFullYear(), 2006);
      	this.assertNull(dt.validate(new Date("12/12/12")));
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getDate(), 12);
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getMonth(), 11);
      	this.assertNull(dt.validate("Jan 1, 1988"));
      	this.assertEqual(dt.toDatatype("Jan 1, 1988").getDate(), 1);
      	this.assertEqual(dt.toDatatype("Jan 1, 1988").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("Jan 1, 1988").getFullYear(), 1988);
      	this.assertNull(dt.validate("Dec 13, 2200"));
      	this.assertEqual(dt.toDatatype("Dec 13, 2200").getDate(), 13);
      	this.assertEqual(dt.toDatatype("Dec 13, 2200").getMonth(), 11);
      	this.assertEqual(dt.toDatatype("Dec 13, 2200").getFullYear(), 2200);
      	this.assertNull(dt.validate("Mar 13, 2200"));
      	this.assertEqual(dt.toDatatype("Mar 13, 2200").getDate(), 13);
      	this.assertEqual(dt.toDatatype("Mar 13, 2200").getMonth(), 2);
      	this.assertEqual(dt.toDatatype("Mar 13, 2200").getFullYear(), 2200);
      	this.assertNotNull(dt.validate("March 13, 2200"));
      	this.assertNull(dt.toDatatype("March 13, 2200"));
      	this.assertNotNull(dt.validate("Bad 13, 2006"));
      	this.assertNull(dt.toDatatype("Bad 13, 2006"));
      	this.assertNotNull(dt.validate("Mar 13, 06"));
      	this.assertNull(dt.toDatatype("Mar 13, 06"));
      	this.assertNotNull(dt.validate("Mar 00, 06"));
      	this.assertNull(dt.toDatatype("Mar 00, 06"));
      	this.assertNotNull(dt.validate("Mar 00, 2006"));
      	this.assertNull(dt.toDatatype("Mar 00, 2006"));
      	this.assertNull(dt.toFormattedString(null));
      	this.assertNull(dt.toFormattedString("Sep 31, 1912"));
      	this.assertNull(dt.toFormattedString("January 31, 1912"));
      	this.assertNotNull(dt.toFormattedString(123412221222));
      	this.assertNotNull(dt.toFormattedString(12341222));
      	this.assertNotNull(dt.toFormattedString(99));
      	this.assertNull(dt.toFormattedString("cat"));
      	this.assertEqual(dt.toFormattedString("Jan 1, 1988"), "Jan 1, 1988");
      	this.assertEqual(dt.toFormattedString("Jan 31, 1988"), "Jan 31, 1988");
      	this.assertEqual(dt.toFormattedString("Sep 30, 1912"), "Sep 30, 1912");
      	this.assertEqual(dt.toFormattedString("Dec 25, 2020"), "Dec 25, 2020");
      	this.assertEqual(dt.toFormattedString("Feb 28, 1998"), "Feb 28, 1998");
      	this.assertEqual(dt.toFormattedString("Jun 7, 2006"), "Jun 7, 2006");
      	this.assertEqual(dt.toFormattedString(new Date("Jan 1, 2002")), "Jan 1, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002")), "Sep 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002").getTime()), "Sep 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Nov 29, 1998").getTime()), "Nov 29, 1998");

      	dt.format = dt.FORMAT_LONG;
      	this.assertNull(dt.validate(new Date("Sep 18, 2009")));
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getDate(), 18);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getMonth(), 8);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getFullYear(), 2009);
      	this.assertNull(dt.validate(new Date("Jan 31, 1998")));
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getDate(), 31);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getMonth(), 0);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getFullYear(), 1998);
      	this.assertNull(dt.validate(new Date("Feb 28, 2006")));
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getDate(), 28);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getMonth(), 1);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getFullYear(), 2006);
      	this.assertNull(dt.validate(new Date("12/12/12")));
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getDate(), 12);
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getMonth(), 11);
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getFullYear(), 1912);
      	this.assertNull(dt.validate("January 1, 1988"));
      	this.assertEqual(dt.toDatatype("January 1, 1988").getDate(), 1);
      	this.assertEqual(dt.toDatatype("January 1, 1988").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("January 1, 1988").getFullYear(), 1988);
      	this.assertNull(dt.validate("April 1, 1988"));
      	this.assertEqual(dt.toDatatype("April 1, 1988").getDate(), 1);
      	this.assertEqual(dt.toDatatype("April 1, 1988").getMonth(), 3);
      	this.assertEqual(dt.toDatatype("April 1, 1988").getFullYear(), 1988);
      	this.assertNull(dt.validate("April 18, 2100"));
    	this.assertEqual(dt.toDatatype("April 18, 2100").getDate(), 18);
      	this.assertEqual(dt.toDatatype("April 18, 2100").getMonth(), 3);
      	this.assertEqual(dt.toDatatype("April 18, 2100").getFullYear(), 2100);
      	this.assertNull(dt.validate("December 18, 1905"));
      	this.assertEqual(dt.toDatatype("December 18, 1905").getDate(), 18);
      	this.assertEqual(dt.toDatatype("December 18, 1905").getMonth(), 11);
      	this.assertEqual(dt.toDatatype("December 18, 1905").getFullYear(), 1905);
      	this.assertNotNull(dt.validate("xDecember 18, 1905"));
      	this.assertNull(dt.toDatatype("xDecember 18, 1905"));
      	this.assertNotNull(dt.validate("December 00, 1905"));
      	this.assertNull(dt.toDatatype("December 00, 1905"));
      	this.assertNotNull(dt.validate("December 32, 1905"));
      	this.assertNull(dt.toDatatype("December 32, 1905"));
      	this.assertNotNull(dt.validate("September 12, 05"));
      	this.assertNull(dt.toDatatype("September 12, 05"));
      	this.assertNotNull(dt.validate("September 12, 0000"));
      	this.assertNull(dt.toDatatype("September 12, 0000"));
      	this.assertNull(dt.toFormattedString(null));
      	this.assertNotNull(dt.toFormattedString(123412221222));
      	this.assertNotNull(dt.toFormattedString(12341222));
      	this.assertNotNull(dt.toFormattedString(99));
      	this.assertNull(dt.toFormattedString("cat"));
      	this.assertEqual(dt.toFormattedString("January 1, 1988"), "January 1, 1988");
      	this.assertEqual(dt.toFormattedString("January 31, 1988"), "January 31, 1988");
      	this.assertEqual(dt.toFormattedString("September 30, 1912"), "September 30, 1912");
      	this.assertEqual(dt.toFormattedString("December 25, 2020"), "December 25, 2020");
      	this.assertEqual(dt.toFormattedString("February 28, 1998"), "February 28, 1998");
      	this.assertEqual(dt.toFormattedString("June 7, 2006"), "June 7, 2006");
      	this.assertEqual(dt.toFormattedString(new Date("Jan 1, 2002")), "January 1, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002")), "September 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002").getTime()), "September 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Nov 29, 1998").getTime()), "November 29, 1998");

      	dt.format = dt.FORMAT_FULL;
      	this.assertNull(dt.validate(new Date("Sep 18, 2009")));
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getDate(), 18);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getMonth(), 8);
      	this.assertEqual(dt.toDatatype(new Date("Sep 18, 2009")).getFullYear(), 2009);
      	this.assertNull(dt.validate(new Date("Jan 31, 1998")));
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getDate(), 31);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getMonth(), 0);
      	this.assertEqual(dt.toDatatype(new Date("Jan 31, 1998")).getFullYear(), 1998);
      	this.assertNull(dt.validate(new Date("Feb 28, 2006")));
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getDate(), 28);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getMonth(), 1);
      	this.assertEqual(dt.toDatatype(new Date("Feb 28, 2006")).getFullYear(), 2006);
      	this.assertNull(dt.validate(new Date("12/12/12")));
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getDate(), 12);
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getMonth(), 11);
      	this.assertEqual(dt.toDatatype(new Date("12/12/12")).getFullYear(), 1912);
      	this.assertNull(dt.validate("Friday, January 1, 1988"));
      	this.assertEqual(dt.toDatatype("Friday, January 1, 1988").getDate(), 1);
      	this.assertEqual(dt.toDatatype("Friday, January 1, 1988").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("Friday, January 1, 1988").getFullYear(), 1988);
      	this.assertNull(dt.validate("Monday, January 31, 2006"));
       	this.assertEqual(dt.toDatatype("Monday, January 31, 2006").getDate(), 31);
      	this.assertEqual(dt.toDatatype("Monday, January 31, 2006").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("Monday, January 31, 2006").getFullYear(), 2006);
      	this.assertNull(dt.validate("Wednesday, January 31, 2006"));
      	this.assertEqual(dt.toDatatype("Wednesday, January 31, 2006").getDate(), 31);
      	this.assertEqual(dt.toDatatype("Wednesday, January 31, 2006").getMonth(), 0);
      	this.assertEqual(dt.toDatatype("Wednesday, January 31, 2006").getFullYear(), 2006);
      	this.assertNull(dt.validate("Tuesday, December 25, 1900"));
       	this.assertEqual(dt.toDatatype("Tuesday, December 25, 1900").getDate(), 25);
      	this.assertEqual(dt.toDatatype("Tuesday, December 25, 1900").getMonth(), 11);
      	this.assertEqual(dt.toDatatype("Tuesday, December 25, 1900").getFullYear(), 1900);
      	this.assertNotNull(dt.validate("Wed, January 31, 2006"));
      	this.assertNull(dt.toDatatype("Wed, January 31, 2006"));
      	this.assertNotNull(dt.validate("Fridayy, January 1, 1988"));
      	this.assertNull(dt.toDatatype("Fridayy, January 1, 1988"));
      	this.assertNotNull(dt.validate("Friday, Jan 1, 1988"));
      	this.assertNull(dt.toDatatype("Friday, Jan 1, 1988"));
      	this.assertNotNull(dt.validate("Friday, January 122, 1988"));
      	this.assertNull(dt.toDatatype("Friday, January 122, 1988"));
      	this.assertNotNull(dt.validate("Friday, January 12, 06"));
      	this.assertNull(dt.toDatatype("Friday, January 12, 06"));
      	this.assertNotNull(dt.validate("Friday, January 32, 2006"));
      	this.assertNull(dt.toDatatype("Friday, January 32, 2006"));
      	this.assertNotNull(dt.validate("Friday, February 31, 2006"));
      	this.assertNull(dt.toDatatype("Friday, February 31, 2006"));
      	this.assertNotNull(dt.validate("12/12/2006"));
      	this.assertNull(dt.toDatatype("12/12/2006"));
      	this.assertNull(dt.toFormattedString(null));
      	this.assertNotNull(dt.toFormattedString(123412221222));
      	this.assertNotNull(dt.toFormattedString(12341222));
      	this.assertNotNull(dt.toFormattedString(99));
      	this.assertNull(dt.toFormattedString("cat"));
      	this.assertEqual(dt.toFormattedString("Saturday, January 1, 1988"), "Friday, January 1, 1988");
      	this.assertEqual(dt.toFormattedString("Monday, January 31, 1988"), "Sunday, January 31, 1988");
      	this.assertEqual(dt.toFormattedString("Tuesday, September 30, 1912"), "Monday, September 30, 1912");
      	this.assertEqual(dt.toFormattedString("Friday, December 25, 2020"), "Friday, December 25, 2020");
      	this.assertEqual(dt.toFormattedString("Thursday, February 28, 2006"), "Tuesday, February 28, 2006");
      	this.assertEqual(dt.toFormattedString("Wednesday, June 7, 2006"), "Wednesday, June 7, 2006");
      	this.assertEqual(dt.toFormattedString(new Date("Saturday, Jan 1, 2002")), "Tuesday, January 1, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002")), "Saturday, September 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Sep 21, 2002").getTime()), "Saturday, September 21, 2002");
      	this.assertEqual(dt.toFormattedString(new Date("Nov 29, 1998").getTime()), "Sunday, November 29, 1998");
	}
*/
});