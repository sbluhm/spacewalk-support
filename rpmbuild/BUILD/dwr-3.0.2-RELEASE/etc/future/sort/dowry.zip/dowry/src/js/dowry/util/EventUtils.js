$package("dowry.util");

/**
 * Helper class to manage DOM event listeners.  This
 * implementation uses its own homegrwon event manager...
 * but it can be easily replaced if you would rather use the
 * event management utilities in your favorite Javascript
 * library.
 *
 */
$class("EventUtils").$as(
{
	/**
	 * Adds an event listener to the specified object.
	 *
	 *
	 * @param obj        the object to add a listener to
	 *
	 * @param eventName  the string name of the event to add
	 *                   (excluding the 'on' prefix)
	 *
	 * @param func       the function to listen to the event
	 *
	 * @return           true, if the event listener was
	 *                   successfully added; false otherwise
	 *
	 */
    addEvent : function(obj, eventName, func)
    {
	    var rc = false;

	    obj = $(obj);
	    if (obj && eventName && func)
	    {
	        if (obj.addEventListener)
	        {
	            obj.addEventListener(eventName, func, false);
	            rc = true;
	        }
	        else if (obj.attachEvent)
	        {
	            rc = obj.attachEvent("on"+eventName, func);
	        }
	        else
	        {
	            if (obj["on"+eventName])
	            {
	                func = this._concatEvents(obj["on"+eventName], func);
	            }

	            obj["on"+eventName] = func;
	            rc = true;
	        }
	    }

	    return rc;
    },

	/**
	 * Takes two event listener function references and
	 * returns a function that calls both, in order.  This
	 * is here to support environments where neither
	 * addEventListener nor attachEvent are provided.
	 *
	 * @param func1  function for the first event listener
	 *
	 * @param func2  function for the second event listener
	 *
	 * @return       a function that calls func1 and then
	 *               calls func2
	 *
	 */
	_concatEvents : function(func1, func2)
	{
	    return function(e)
	    {
	    	func1.call(null, e);
	    	func2.call(null, e);
	    }
	}
});