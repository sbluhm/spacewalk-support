$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.CheckboxWidget");
$import("dowry.test.Test");

$class("CheckboxWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.CheckboxWidget();
	}
});