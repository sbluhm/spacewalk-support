package dowry.hibernate;

import java.util.*;
import org.hibernate.cfg.*;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.util.*;
import dowry.*;

/**
 * Object representation of an Object datatype.
 *
 */
public class ObjectType
    extends dowry.datatype.ObjectType
    implements HibernateType
{
	/**
	 * Generates a map of attributes for the specified
	 * Hibernate property, based on the rules of this
	 * datatype.
	 *
	 * @param entityMapper  a handle back to the entity
	 *                      mapper processing the Hibernate
	 *                      configuration
	 *
	 * @param property      the Hibernate property
	 *
	 * @return              a Map containing the relevant
	 *                      Dowry attributes
	 *
	 */
	public Map toConfiguration(HibernateEntityMapper entityMapper,
	                           Property property)
	{
		Map m = new HashMap();

		String propertyType = entityMapper.getPropertyType(property);
		m.put(JAVA_CLASS, propertyType);
		m.put(TYPE, entityMapper.toType(propertyType));
		m.put(REQUIRED, new Boolean(!property.isOptional()));

		// get the name of the property that is the
		// unique identifier for this object
		HibernateProvider provider =
		    entityMapper.getHibernateProvider();

		if (provider != null)
		{
			Configuration cfg = provider.getConfiguration();
	        PersistentClass propertyClass = cfg.getClassMapping(propertyType);
			if (propertyClass != null)
			{
		        if (propertyClass.hasIdentifierProperty())
		        {
			        Property idProperty = propertyClass.getIdentifierProperty();
			        if (idProperty != null)
			        {
						String idName = entityMapper.getPropertyName(idProperty);
						m.put(KEY, idName);
					}
				}
			}
		}

		return m;
	}
}