$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.DatePickerWidget");
$import("dowry.test.Test");

$class("DatePickerWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.DatePickerWidget();
	}
});