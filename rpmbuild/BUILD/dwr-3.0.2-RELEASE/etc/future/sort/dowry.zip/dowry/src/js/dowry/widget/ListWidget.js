$package("dowry.widget");

/**
 * Object representation of a widget that is some sort of
 * list.
 *
 * <p>
 * While this is a base class for any widget involving
 * data lists, this base widget may be used for display
 * lists such as <code>&lt;ul&gt;</code> and
 * <code>&lt;ol</code>.
 * </p>
 *
 */
$class("ListWidget").$extends("Widget").$with("Transformable").$as(
{
    /**
     * Adds the specified values to the list.
     *
     * @param vals  an array of values that are type
     *              appropriate for the element's datatype
     *
     */
    addValues : function(vals)
    {
        vals = this.transform(vals);
        var ele = this.getElement();

        if (ele && vals != null)
        {
            // count existing list items
            var len = 0;
            for (var i=0; i < ele.childNodes.length; i++)
            {
                if (ele.childNodes[i].nodeName.toLowerCase() == "li")
                {
                    len++;
                }
            }

            for (var i=0; i < vals.length; i++)
            {
                var val = vals[i];

                // convert the raw value
                var dt = this.getDatatype();
                if (dt)
                {
                    val = dt.toDatatype(val);
                }

                // add a new list item
                var itemIndex = len+i;
                var li = this.createListItem(val, itemIndex);
                if (li)
                {
                    this._setValueImpl(li, val);
                    ele.appendChild(li);
                }
            }
        }
    },

    /**
     * Creates a <code>&lt;li&gt;</code> element.
     *
     * @param val        the value of the item
     *
     * @param itemIndex  the index of the item
     *
     */
    createListItem : function(val, itemIndex)
    {
        return document.createElement("li");
    },

    /**
     * Gets the value of the bound element.  In the case of
     * an <code>&lt;ul&gt;</code> or <code>&lt;ol&gt;
     * </code>, however, this is not applicable... null
     * will always be returned.
     *
     * @return  the value
     *
     */
    getValue : function()
    {
        return null;
    },

    /**
     * Removes all values from the list.
     *
     */
    removeAllValues : function()
    {
        var ele = this.getElement();
        if (ele)
        {
            while(ele.childNodes.length > 0)
            {
                ele.removeChild(ele.firstChild);
            }
        }
    },

    /**
     * Sets the value of the bound element.  In the case of
     * an <code>&lt;ul&gt;</code> or <code>&lt;ol&gt;
     * </code>, however, this is not entirely applicable...
     * so this method treats it like a remove/add.
     *
     * @param val  the value to set
     *
     */
    setValue : function(val)
    {
        if (val == null || !val.join)
        {
            val = [ val ];
        }

        this.removeAllValues();
        this.addValues(val);
    }
 });