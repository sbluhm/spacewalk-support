package dowry.hibernate;

import org.hibernate.*;
import org.hibernate.cfg.*;

/**
 * HibernateProvider is a helper for Dowry applications to
 * specify their Hibernate setup.
 *
 */
public interface HibernateProvider
{
	/**
	 * Returns the Hibernate configuration to be used with
	 * Dowry.  Implementors should ensure that this method
	 * always returns a valid configuration.
	 *
	 * @return the Hibernate configuration
	 *
	 */
	public Configuration getConfiguration();

	/**
	 * Returns the Hibernate session factory to be used with
	 * Dowry.  Implementations hsould ensure that this
	 * method returns an open session factory.
	 *
	 * @return the Hibernate session factory
	 *
	 */
	public SessionFactory getSessionFactory();
}