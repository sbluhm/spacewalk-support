$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.LoadingWidget");
$import("dowry.test.Test");

$class("LoadingWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.LoadingWidget();
	}
});