$package("demo");

$import("dowry.datatype.NumberType");

$class("JerseyNumberType").$extends("NumberType").$as(
{
	validate : function(val)
	{
		var msg = this.$super(arguments);
		if (typeof msg == "string" && val)
		{
			var jerseyNum = this.toDatatype(val);
			var positions = Dowry.getValue("positions");

			if (jerseyNum != null && positions != null)
			{
				var match = false;

				for (var i=0; i < positions.length; i++)
				{
					if (positions[i] == null ||
					    positions[i].abbreviation == null)
					{
						continue;
					}

					var abbr = positions[i].abbreviation;

					// 1-19
					if (abbr == "QB" ||
					    abbr == "K" ||
					    abbr == "P")
					{
						if (jerseyNum > 0 && jerseyNum < 20)
						{
							match = true;
							break;
						}
					}

					// 20-49
					else if (abbr == "RB" ||
						     abbr == "FB" ||
					         abbr == "CB" ||
					         abbr == "S" ||
					         abbr == "FS" ||
					         abbr == "SS")
					{
						if (jerseyNum > 19 && jerseyNum < 50)
						{
							match = true;
							break;
						}
					}

					// 50-59
					else if (abbr == "LB" ||
					         abbr == "MLB" ||
					         abbr == "OLB" ||
					         abbr == "LOLB" ||
					         abbr == "ROLB")
					{
						if (jerseyNum > 49 && jerseyNum < 60)
						{
							match = true;
							break;
						}
					}

					// 60-79
					else if (abbr == "OT" ||
					         abbr == "OG" ||
					         abbr == "C"  ||
					         abbr == "LT" ||
					         abbr == "RT" ||
					         abbr == "LG" ||
					         abbr == "RG")
					{
						if (jerseyNum > 59 && jerseyNum < 80)
						{
							match = true;
							break;
						}
					}

					// 80-89
					else if (abbr == "TE")
					{
						if (jerseyNum > 79 && jerseyNum < 90)
						{
							match = true;
							break;
						}
					}

					// 10-19 *or* 80-89
					else if (abbr == "WR")
					{
						if (jerseyNum > 9 && jerseyNum < 20)
						{
							match = true;
							break;
						}
						else if (jerseyNum > 79 && jerseyNum < 90)
						{
							match = true;
							break;
						}
					}

					// 90-99
					else if (abbr == "DT" ||
					         abbr == "DE" ||
					         abbr == "LE" ||
					         abbr == "RE" ||
					         abbr == "NT")
					{
						if (jerseyNum > 89 && jerseyNum < 100)
						{
							match = true;
							break;
						}
					}
				}

				if (!match)
				{
					msg = "Jersey Number must be within range for player's " +
					      "position.";
				}
			}
		}

		return msg;
	}
});
