$package("dowry.widget");

$import("dowry.widget.Transformable");
$import("dowry.test.Test");

$class("TransformableTest").$extends("Test").$as(
{
	testTransform : function()
	{
		$class("TransformableObject").$with("dowry.widget.Transformable").$as(
		{
			count : 0,
			keys : new Object(),

			transformValue : function(val, key)
			{
				this.count++;
				if (key)
				{
					this.keys[key] = true;
				}
				return val;
			}
		});

		var obj = new TransformableObject();
		this.assertEqual(obj.count, 0);
		var a = obj.transform([1, 2, 3]);
		this.assertEqual(obj.count, 3);
		this.assertEqual(a.length, 3);

		var obj = new TransformableObject();
		this.assertEqual(obj.count, 0);
		this.assertEqual(obj.count, 0);
		this.assertNotEqual(obj.keys.foo, true);
		this.assertNotEqual(obj.keys.bar, true);
		this.assertNotEqual(obj.keys.baz, true);
		var a = obj.transform({foo:1, bar:2, baz:3});
		this.assertEqual(obj.count, 3);
		this.assertEqual(a.length, 3);
		this.assertEqual(obj.keys.foo, true);
		this.assertEqual(obj.keys.bar, true);
		this.assertEqual(obj.keys.baz, true);
	}
});