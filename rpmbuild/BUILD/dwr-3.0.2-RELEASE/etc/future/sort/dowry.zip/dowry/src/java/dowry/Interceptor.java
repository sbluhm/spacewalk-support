package dowry;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Interceptor intercepts lifecycle events at various points
 * in the lifecycle of DWR.
 *
 */
public interface Interceptor
{
	/**
	 * Called to indicate the startup of DWR.  This method
	 * will be called after DWR finishes its own
	 * initialization, but before any remote invocations
	 * begin.
	 *
	 * @param cfg  the servlet configuration
	 *
	 */
	public void onInit(ServletConfig cfg);

	/**
	 * Called to indicate the start of invocation of DWR.
	 * This will be called before DWR starts processing the
	 * incoming invocation.
	 *
	 * @param req  the servlet request
	 *
	 * @param res  the servlet response
	 *
	 */
	public void onInvoke(HttpServletRequest req, HttpServletResponse res);

	/**
	 * Called to indicate the successful handling of a
	 * DWR invocation.  This indicates that no exceptions
	 * were thrown during DWR's processing, and no error
	 * messages are being marshalled to the DWR client.
	 *
	 * @param req  the servlet request
	 *
	 * @param res  the servlet response
	 *
	 */
	public void onSuccess(HttpServletRequest req, HttpServletResponse res);

	/**
	 * Called to indicate the handling of a DWR invocation
	 * has resulted in an error.  This may happen if an
	 * exception was thrown during DWR's processing, or if
	 * an error message was marshalled to the client.
	 *
	 * @param req  the servlet request
	 *
	 * @param res  the servlet response
	 *
	 */
	public void onError(HttpServletRequest req, HttpServletResponse res);

	/**
	 * Called to indicate the shutdown of DWR.  This method
	 * will be called just prior to DWR performs its own
	 * cleanup.
	 *
	 */
	public void onDestroy();
}