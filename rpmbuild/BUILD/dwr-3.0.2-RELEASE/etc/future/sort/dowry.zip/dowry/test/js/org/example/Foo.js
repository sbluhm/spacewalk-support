$package("org.example");

$import("org.example.Bar");
$import("org.example.Baz");
$import("org.example.util.Trimmable");

$class("Foo").$with("Trimmable").$as(
{
	Foo : function()
	{
		alert("[FOO]:" + this.$class);
	},

	a : function()
	{
		alert("[FOO] a");
	},

	b : function()
	{
		alert("[FOO] b");
	},

	buggy : function()
	{
		var bar = new org.example.Bar();
		bar.buggy();
	}
});
