package dowry.datatype;

import dowry.*;

/**
 * Object representation of a time datatype.
 *
 */
public class TimeType extends DateType
{
	/**
	 * Constant for the datatype's name.
	 *
	 */
	public static final String NAME = Messages.get("time");

	/**
	 * Construct a new instance of TimeType with the
	 * appropriate <code>full</code>, <code>long</code>,
	 * <code>medium</code>, and <code>short</code> patterns
	 * for time-only data.
	 *
	 */
	public TimeType()
	{
		super();

		fullPattern   = Messages.get("timeFullPattern");
		longPattern   = Messages.get("timeLongPattern");
		mediumPattern = Messages.get("timeMediumPattern");
		shortPattern  = Messages.get("timeShortPattern");
	}

	/**
	 * Gets the name of the Javascript class that serves
	 * as the client side equivalent to this Java Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass()
	{
		return TimeType.class.getName();
	}

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName)
	{
		return (typeName != null && typeName.equals(NAME));
	}

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * <p>
	 * This implementation returns 'time'.
	 * </p>
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c)
	{
		return NAME;
	}
}