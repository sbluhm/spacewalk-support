$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.Widget");
$import("dowry.test.Test");

$class("WidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.Widget();
	}
});