$package("dowry.widget");

/**
 * Object represenation of a UI widget that knows how to
 * handle text areas.
 *
 */
$class("TextAreaWidget").$extends("TextInputWidget").$as(
{
    /**
     * When the TextAreaWidget is started, associate an
     * event to validate the input.  This will also restrict
     * the field's input to the specified valid characters,
     * and set the maximum length on this field (if these
     * properties are provided via the associated datatype).
     *
     */
    start : function()
    {
        this.$super(arguments);

        // super set the maxLength property...
        // but max length is not a real property
        // of a textarea, so use an event handler
        // instead...
        var ele = this.getElement();
        if (ele && ele.maxLength)
        {
            Dowry.event.addEvent(ele, "keyup",  this._maxLength);
        }
    },

    /**
     * Polices the maximum length for the textarea.
     *
     */
    _maxLength : function()
    {
        // get associated
        var ele = this.getElement();
        var dt = this.getDatatype();
        if (ele && dt)
        {
            var cfg = dt.toConfiguration();
            if (cfg && cfg.maxLength)
            {
                // get the raw input value...
                var s = ele.value;

                // if its too long... truncate it...
                if (s != null &&
                    s.length > cfg.maxLength)
                {
                    s = s.substring(0, cfg.maxLength);
                    ele.value = s;
                }
            }
        }
    }
});