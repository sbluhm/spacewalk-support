/**
 * You needs to roll your own <code>$()</code> function if
 * you want people to take your toolkit seriously!
 *
 * <p>
 * This isn't a particularly elaborate implementation.
 * Generally speaking, it is simply a shortcut to using
 * <code>document.getElementById()</code>, except that if
 * you already pass in an element, it will give you back
 * the element you passed in.  It is the only one I know,
 * however, that contains a fix for Internet Explorer's
 * broken implementation of <code> getElementById()</code>.
 * In IE, <code>getElementById()</code> might return an
 * element that does not match the specified ID, if it
 * matches the element's <code>name</code> attribute...
 * nice, huh?
 *
 * <p>
 * Rather than fight over it, we only define the
 * <code>$()</code> function if one doesn't already exist.
 * Otherwise, we'll assume that your implementation is at
 * least as usable as ours.
 * </p>
 *
 * @param id  the id of the element on the page
 *
 * @return    the element associated with the id
 *
 */
//function $(id)
if (!window["$"])
{
    window["$"] = function(id)
    {
    	var ele = null;
        if (typeof id == "string")
        {
            ele = document.getElementById(id);

            // this incredibly scary hack is because
            // internet explorer will return elements the
            // that do not match id, if they match the
            // element's 'name' attribute... yuck!

    		// can't trust ele.id because in the case of a
    		// form, a field named 'id' will eclipse the
    		// element's attribute 'id'... can't use
    		// getAttribute(), because in internet explorer,
    		// this will still return the field 'id' when
    		// ele is a form element
    		var badMatches = null;
    		while (ele != null &&
    		       ele.id != id &&
    		       ele.getAttributeNode("id") != null &&
    		       ele.getAttributeNode("id").value != id)
    		{
				if (badMatches == null)
				{
					badMatches = new Array();
				}
				else if (badMatches.length > 1000)
				{
					// hopefully, this is sutiably high...
					// if we haven't sorted through all the
					// bad matches yet, then we are probably
					// in an endless loop for some reason...
					// better to just go with whatever
					// element we are getting back from
					// getElementsById()
					break;
				}

				badMatches[badMatches.length] = ele;
				ele.removeAttribute("name");
    			ele = document.getElementById(id);
    		}

			if (badMatches != null)
			{
	    		for (var i=0; i < badMatches.length; i++)
	    		{
	    			badMatches[i].setAttribute("name", id);
	    		}
			}
        }
	    else
    	{
    		ele = id;
    	}

        return ele;
    }
}
