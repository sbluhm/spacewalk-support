$package("org.example");

$import("org.example.Baz");

$class("Bar").$extends("Foo").$as(
{
	Bar : function()
	{
		alert("[BAR]:"+this.$class);
		this.$super(arguments);
	},

	trim : function(s)
	{
		alert("[BAR] trim");
		return s;
	},

	a : function()
	{
		alert("[BAR] a");
		this.$super(arguments);
		this.b();
	},

	buggy : function()
	{
		notAValidVar++;
	}
});