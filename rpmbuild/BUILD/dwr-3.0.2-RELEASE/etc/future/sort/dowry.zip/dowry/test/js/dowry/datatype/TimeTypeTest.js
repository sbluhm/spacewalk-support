$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.TimeType");
$import("dowry.test.Test");

$class("TimeTypeTest").$extends("Test").$as(
{
	test : function()
	{
		var dt = new dowry.datatype.TimeType();
	}
});