package dowry;

/**
 * Utility for conversion of Java objects into Javascript
 * declarations.
 *
 */
public interface Javascript
{
	/**
	 * Returns the specified Java object as a Javascript
	 * variable assignment.  This version of the method
	 * will always create a new variable.
	 *
	 * @param id      the variable name the object should be
	 *                assigned to
	 *
	 * @param var     the Java object to be expressed as a
	 *                Javascript variable
	 *
	 * @return        string containing the Javascript code
	 *                to perform the variable assignments
	 */
	public String var(String id, Object var);

	/**
	 * Returns the specified Java object as a Javascript
	 * variable assignment.  This version will create a
	 * new variable or simply make an assignment to an
	 * existing variable name, depending on the value of the
	 * newVar parameter.
	 *
	 * @param id      the variable name the object should be
	 *                assigned to
	 *
	 * @param var     the Java object to be expressed as a
	 *                Javascript variable
	 *
	 * @param newVar  if this is true, this will create a
	 *                new variable with the assigned id;
	 *                otherwise, it will just assign to the
	 *                existing variable
	 *
	 * @return        string containing the Javascript code
	 *                to perform the variable assignments
	 */
	public String var(String id, Object var, boolean newVar);
}