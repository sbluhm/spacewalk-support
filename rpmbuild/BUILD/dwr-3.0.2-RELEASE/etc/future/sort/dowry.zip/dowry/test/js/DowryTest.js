$import("Dowry");
$import("dowry.test.Test");

$class("DowryTest").$extends("Test").$as(
{
	test : function()
	{
		this.assertNotNull(Dowry);
	}
});