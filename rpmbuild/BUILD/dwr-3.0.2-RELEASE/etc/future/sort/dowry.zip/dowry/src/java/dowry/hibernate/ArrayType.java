package dowry.hibernate;

import java.util.*;
import org.hibernate.mapping.Property;
import dowry.*;


/**
 * Object representation of an Array datatype.
 *
 */
public class ArrayType
   extends dowry.datatype.ArrayType
   implements HibernateType
{
	/**
	 * Generates a map of attributes for the specified
	 * Hibernate property, based on the rules of this
	 * datatype.
	 *
	 * @param entityMapper  a handle back to the entity
	 *                      mapper processing the Hibernate
	 *                      configuration
	 *
	 * @param property      the Hibernate property
	 *
	 * @return              a Map containing the relevant
	 *                      Dowry attributes
	 *
	 */
	public Map toConfiguration(HibernateEntityMapper entityMapper,
	                           Property property)
	{
		Map cfg = new HashMap();

		String propertyType = entityMapper.getPropertyType(property);
		cfg.put(JAVA_CLASS, propertyType);
		cfg.put(TYPE, entityMapper.toType(propertyType));
		cfg.put(REQUIRED, new Boolean(!property.isOptional()));

		// get the property type expressed using the generics syntax
		propertyType = entityMapper.getPropertyType(property, true);

		// pull out the element type
		int left = propertyType.indexOf("<");
		int right = propertyType.indexOf(">");
		if (left > 0 && right > 0 && left < right)
		{
			propertyType = propertyType.substring(left+1, right);
			cfg.put(ELEMENT_TYPE, entityMapper.toType(propertyType));
		}

		return cfg;
	}
}