$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.MultiSelectWidget");
$import("dowry.test.Test");

$class("MultiSelectWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.MultiSelectWidget();
	}
});