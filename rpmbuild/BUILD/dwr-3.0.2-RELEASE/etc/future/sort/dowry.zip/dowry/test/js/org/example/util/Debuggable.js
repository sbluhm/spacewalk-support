$package("org.example.util");

$mixin("Debuggable").$as(
{
	trim : function(s)
	{
		alert("[DEBUGGABLE] trim");
		return s;
	}
});
