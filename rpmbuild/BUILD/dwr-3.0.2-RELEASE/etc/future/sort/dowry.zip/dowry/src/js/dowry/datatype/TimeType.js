$package("dowry.datatype");

/**
 * Object representation of a time datatype.  This only
 * differs from DateType in that it contains the appropriate
 * <code>full</code>, <code>long</code>, <code>medium
 * </code>, and <code>short</code> patterns for time-only
 * data.
 *
 */
$class("TimeType").$extends("DateType").$as(
{
    /**
     * Constant for the parse/format mask to use with the
     * full date format.
     *
     */
    FULL : Dowry.msgs.getMessage("timeFullPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * long date format.
     *
     */
    LONG : Dowry.msgs.getMessage("timeLongPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * medium date format.
     *
     */
    MEDIUM : Dowry.msgs.getMessage("timeMediumPattern"),

    /**
     * Constant for the parse/format mask to use with the
     * short date format.
     *
     */
    SHORT : Dowry.msgs.getMessage("timeShortPattern")
});