$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.ActivityMonitorWidget");
$import("dowry.test.Test");

$class("ActivityMonitorWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.ActivityMonitorWidget();
	}
});