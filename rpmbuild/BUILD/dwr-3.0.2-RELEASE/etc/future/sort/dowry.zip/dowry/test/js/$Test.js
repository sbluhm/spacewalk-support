$import("$");
$import("dowry.test.Test");

$class("$Test").$extends("Test").$as(
{
	setup : function()
	{
		this.createEle("baz", "foo");
		this.createEle("bubba", "foo");
		this.createEle("foo", "bar");
		this.createEle("wonka", "foo");
	},

	test$ : function()
	{
		var ele = $("foo");
		this.assertNotNull(ele);
		this.assertEqual(ele.id, "foo");
	},

	testGetElementById : function()
	{
		var ignore = true;

		/*@cc_on @*/
		/*@if (@_win32)
		{
			ignore = false;
		}
		/*@end @*/

		if (!ignore)
		{
			var ele = document.getElementById("foo");
			this.assertNotNull(ele);
			this.assertNotEqual(ele.id, "foo");
			this.assertEqual(ele.id, "baz");
		}
	},

	teardown : function()
	{
		this.removeEles();
	},

	createEle : function(id, name)
	{
		var input = "<input type='hidden' id='"+id+"' name='"+name+"' />";

		var div = document.getElementById("elediv");
		if (!div)
		{
			div = document.createElement("div");
			div.id="elediv";
			document.body.appendChild(div);
		}

		div.innerHTML += input;
	},

	removeEles : function()
	{
		var div = document.getElementById("elediv");
		if (div && div.parentNode)
		{
			div.parentNode.removeChild(div);
		}
	}
});