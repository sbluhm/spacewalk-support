$package("demo");

$import("dowry.widget.TableWidget");

$class("LinkTableWidget").$extends("TableWidget").$as(
{
	key : "id",
	label : null,
	url : null,

	start : function()
	{
		var label = this.label;
		if (label == null)
		{
			label = this.key;
		}

		if (label != null && this.url != null)
		{
			var cols = this.getColumns();
			if (cols)
			{
				for (var i=0; i < cols.length; i++)
				{
					var col = cols[i];
					var dt = $(col).dowryDatatype;

					var s = null;
					if (typeof col == "string" && dt)
					{
						if (label == dt.property || label == col)
						{
							if (this.cells == null)
							{
								this.cells = new Array();
							}

							this.cells[i] = this.createLink;
						}
					}
				}
			}
		}

		this.$super(arguments);
	},

	createLink : function(val)
	{
		var link = null;

		if (this.url && this.key && val && val[this.key])
		{
			var label = this.label;
			if (!label)
			{
				label = this.key;
			}

			link = document.createElement("a");
			link.innerHTML = val[label];
			link.setAttribute("href", this.url + "?" +
			                          this.key + "="+ val[this.key]);

		}

		return link;
	}
});
