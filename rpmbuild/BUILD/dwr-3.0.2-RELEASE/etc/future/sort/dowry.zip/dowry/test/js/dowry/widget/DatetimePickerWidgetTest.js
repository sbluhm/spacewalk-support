$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.DatetimePickerWidget");
$import("dowry.test.Test");

$class("DatetimePickerWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.DatetimePickerWidget();
	}
});