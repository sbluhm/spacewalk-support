$package("dowry.widget");

$import("Dowry");
$import("dowry.widget.SelectWidget");
$import("dowry.test.Test");

$class("SelectWidgetTest").$extends("Test").$as(
{
	test : function()
	{
		var widget = new dowry.widget.SelectWidget();
	}
});