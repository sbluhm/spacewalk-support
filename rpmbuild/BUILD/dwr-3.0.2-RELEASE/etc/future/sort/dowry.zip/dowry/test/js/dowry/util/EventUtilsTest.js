$package("dowry.util");

$import("dowry.util.EventUtils");
$import("dowry.test.Test");

$class("EventUtilsTest").$extends("Test").$as(
{
	setup : function()
	{
		this.event = new dowry.util.EventUtils();
	},

	testAddEvent : function()
	{
		// not sure what else we can test without
		// some way of automating a browser event
		// firing...
		this.assert(this.event.addEvent);
	},

	teardown : function()
	{
		this.event = null;
	}
});