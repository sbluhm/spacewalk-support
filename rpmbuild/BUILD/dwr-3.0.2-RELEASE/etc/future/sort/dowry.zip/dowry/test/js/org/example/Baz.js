$package("org.example");

$import("org.example.Foo");

$class("Baz").$as(
{
	Baz : function()
	{
		alert("[BAZ]:"+this.$class);
	}
});