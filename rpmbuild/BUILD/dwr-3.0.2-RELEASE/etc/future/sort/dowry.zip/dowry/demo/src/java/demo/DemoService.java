package demo;

import java.util.*;
import org.hibernate.*;

public class DemoService
{
	public Conference getConference(Long id)
	{
        Session session = Persistence.getSession();
        return (Conference) session.get(Conference.class, id);
	}

	public Division getDivision(Long id)
	{
        Session session = Persistence.getSession();
        return (Division) session.get(Division.class, id);
	}

	public Location getLocation(Long id)
	{
        Session session = Persistence.getSession();
        return (Location) session.get(Location.class, id);
	}

	public Owner getOwner(Long id)
	{
        Session session = Persistence.getSession();
        return (Owner) session.get(Owner.class, id);
	}

	public Player getPlayer(Long id)
	{
        Session session = Persistence.getSession();
        return (Player) session.get(Player.class, id);
	}

	public Position getPosition(Long id)
	{
        Session session = Persistence.getSession();
        return (Position) session.get(Position.class, id);
	}

	public Team getTeam(Long id)
	{
        Session session = Persistence.getSession();
        return (Team) session.get(Team.class, id);
	}

	public List getConferences()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Conference").list();
	}

	public List getDivisions()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Division").list();
	}

	public List getLocations()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Location").list();
	}

	public List getOwners()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Owner").list();
	}

	public List getPlayers()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Player").list();
	}

	public List getPositions()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Position").list();
	}

	public List getTeams()
	{
        Session session = Persistence.getSession();
        return session.createQuery("from Team").list();
	}

	public Conference saveConference(Conference o)
	{
        Session session = Persistence.getSession();
        return (Conference) session.merge(o);
	}

	public Division saveDivision(Division o)
	{
        Session session = Persistence.getSession();
        return (Division) session.merge(o);
	}

	public Location saveLocation(Location o)
	{
        Session session = Persistence.getSession();
        return (Location) session.merge(o);
	}

	public Owner saveOwner(Owner o)
	{
        Session session = Persistence.getSession();
        return (Owner) session.merge(o);
	}

	public Player savePlayer(Player o)
	{
        Session session = Persistence.getSession();
        return (Player) session.merge(o);
	}

	public Position savePosition(Position o)
	{
        Session session = Persistence.getSession();
        return (Position) session.merge(o);
	}

	public Team saveTeam(Team o)
	{
        Session session = Persistence.getSession();

		// probably a more elegant way to handle this,
		// but this will work in a pinch...
		if (o.getId() != null)
		{
			Team t = getTeam(o.getId());
			o.setPlayers(t.getPlayers());
		}
        if (o.getLocation() != null)
        {
        	o.setLocation(saveLocation(o.getLocation()));
        }
        if (o.getDivision() != null)
        {
        	o.setDivision(saveDivision(o.getDivision()));
        }
        if (o.getOwner() != null)
        {
        	o.setOwner(saveOwner(o.getOwner()));
        }

        return (Team) session.merge(o);
	}
}