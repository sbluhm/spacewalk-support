$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.Datatype");
$import("dowry.test.Test");

$class("DatatypeTest").$extends("Test").$as(
{
	testCompare : function()
	{
		var dt = new dowry.datatype.Datatype();
      	this.assertEqual(dt.compare(1,2), -1);
      	this.assertEqual(dt.compare(2,1), 1);
      	this.assertEqual(dt.compare(1,1), 0);
      	this.assertEqual(dt.compare(null,1), -1);
      	this.assertEqual(dt.compare(null,null), 0);
      	this.assertEqual(dt.compare("cat",null), 1);
      	this.assertEqual(dt.compare("cat","cat"), 0);
      	this.assertEqual(dt.compare("cat","dog"), -1);
      	this.assertEqual(dt.compare("cat",1), -1);
	},

	testToConfiguration : function()
	{
		var dt = new dowry.datatype.Datatype();
      	this.assertEqual(dt.toConfiguration().$class, "dowry.datatype.Datatype");
	},

	testToDatatype : function()
	{
		var dt = new dowry.datatype.Datatype();
      	this.assertEqual(dt.toDatatype("  should_trim  "), "should_trim");
      	this.assertEqual(dt.toDatatype("should_trim  "), "should_trim");
      	this.assertEqual(dt.toDatatype("  should_trim"), "should_trim");
	},

	testToFormattedString : function()
	{
		var dt = new dowry.datatype.Datatype();
      	this.assertEqual(dt.toFormattedString("truck"), "truck");
      	this.assertEqual(dt.toFormattedString("truck  "), "truck");
      	this.assertEqual(dt.toFormattedString(" big truck  "), "big truck");
      	this.assertEqual(dt.toFormattedString(null), null);
	},

	testTrim : function()
	{
		var dt = new dowry.datatype.Datatype();
        this.assertEqual(dt.trim(" trim"), "trim");
      	this.assertEqual(dt.trim("trim   "), "trim");
      	this.assertEqual(dt.trim("  trim   "), "trim");
	},

	testValidate : function()
	{
		var dt = new dowry.datatype.Datatype();
		this.assertEqual(dt.required, false);
		this.assertNull(dt.validate("something"));
		this.assertNull(dt.validate(null));

		var dt = new dowry.datatype.Datatype();
		dt.required = false;
		this.assertEqual(dt.required, false);
		this.assertNull(dt.validate("something"));
		this.assertNull(dt.validate(null));

		var dt = new dowry.datatype.Datatype();
		dt.required = true;
		this.assertEqual(dt.required, true);
		this.assertNull(dt.validate("something"));
		this.assertEqual(dt.validate(null), dt.ERROR_REQUIRED);
	}
});