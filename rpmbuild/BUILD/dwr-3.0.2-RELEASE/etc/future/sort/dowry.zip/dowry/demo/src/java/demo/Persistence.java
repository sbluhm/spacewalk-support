package demo;

import org.hibernate.*;
import org.hibernate.cfg.*;


/**
 * Persistence provides a static utility for interacting
 * with the Hibernate persistence tier. Most of these
 * methods are exposed for the framework. Typically,
 * developers should only need to use getSession().
 *
 */
public class Persistence
{
	private static Configuration  cfg;
    private static SessionFactory factory;
    private static ThreadLocal hibernateHolder = new ThreadLocal();

    /**
     * Hide constructor on static utility.
     *
     */
    private Persistence()
    {
    }

    /**
     * Get the Hiberante configuration.
     *
     * @return the Hibernate configuration
	 *
     */
    public static Configuration getConfiguration()
    {
        return cfg;
    }

    /**
     * Get the current Hibernate session.
     *
     * @return current Hibernate session
	 *
     */
    public static Session getSession()
    {
        return (Session) hibernateHolder.get();
    }

    /**
     * Get the Hibernate session factory.
     *
     * @return the Hibernate session factory
	 *
     */
    public static SessionFactory getSessionFactory()
    {
        return factory;
    }

    /**
     * Initialize Hibernate using the specified Hibernate
     * configuration.  If Hibernate is already initialized,
     * subsequent calls will be ignored.
     *
     * @param cfg  the Hibernate configuration
 	 *
     */
    public static void init(Configuration cfg)
    {
        if (factory == null && cfg != null)
        {
        	Persistence.cfg = cfg;
            factory = cfg.buildSessionFactory();
        }
    }

    /**
     * Initialize Hibernate using the specified Hibernate
     * configuration and session factory. If Hibernate is
     * already initialized, subsequent calls will be
     * ignored.
     *
     * @param cfg      the Hibernate configuration
 	 *
 	 * @param factory  the Hibernate session factory
 	 *
     */
    public static void init(Configuration cfg, SessionFactory factory)
    {
        if (cfg != null && factory != null)
        {
        	Persistence.cfg = cfg;
            Persistence.factory = factory;
        }
    }

    /**
     * Open Hibernate session.
     *
     */
    public static void open()
    {
        if (hibernateHolder.get() != null)
        {
        	// for some reason we already have
        	// an open session... let's try to
        	// clean it up first...
			close();
        }

        if (factory != null)
        {
            Session sess = factory.openSession();
            hibernateHolder.set(sess);
        }
    }

    /**
     * Begin a transaction.
     *
     * @return  the open transaction
     *
     */
    public static Transaction begin()
    {
        Transaction tx = null;

        Session sess = getSession();
        if (sess != null)
        {
            tx = sess.beginTransaction();
        }

        return tx;
    }

    /**
     * Rollback a transaction.
     *
     * @param tx  the transaction to rollback
     *
     */
    public static void rollback(Transaction tx)
    {
        if (tx != null)
        {
            try
            {
                tx.rollback();
            }
            catch(HibernateException ex)
            {
                // probably don't need to do anything--
                // this is likely being called because
                // of another exception, and we don't
                // want to mask it with yet another
                // exception.
            }
        }
    }

    /**
     * Commit a transaction.
     *
     * @param tx  the transaction to commit.
	 *
     */
    public static void commit(Transaction tx)
    {
        if (tx != null)
        {
            tx.commit();
        }
    }

    /**
     * Close the Hibernate session.
     *
     */
    public static void close()
    {
        Session sess = getSession();

        if (sess != null)
        {
            hibernateHolder.set(null);
            sess.close();
        }
    }

    /**
     * Cleanup Hibernate.
     *
     */
    public static void destroy()
    {
        if (factory != null)
        {
            factory.close();
            factory = null;
        }
    }
}