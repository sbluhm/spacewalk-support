package dowry;

import java.util.*;

/**
 * DatatypeManager manages the mapping of Java classes to
 * Dowry datatypes.
 *
 */
public interface DatatypeManager
{
	/**
	 * Registers a datatype.  This datatype will not be
	 * associated to any specific Java class, and thus
	 * will not be returned via <code>getDatatype()</code>.
	 * However, it will be available via
	 * <code>getDatatypes()</code>, and possibly via
	 * <code>getDatatypeByType()</code>.
	 *
	 * @param  datatype  the datatype to be registered
	 *
	 */
	public void addDatatype(Datatype datatype);

	/**
	 * Register a datatype to handle the specified class.
	 * This datatype will be used to handle any object that
	 * is an instance of this class, or any objects
	 * that extends or implements the specified class
	 * (such that the closest match wins).
	 *
	 * @param  c         the class to register this datatype
	 *                   to
	 *
	 * @param  datatype  the datatype to be registered
	 *
	 */
	public void addDatatype(Class c, Datatype datatype);

	/**
	 * Returns the classes that have been registered to
	 * a datatype.
	 *
	 * @return  a set of Class objects registered to a
	 *          datatype
	 *
	 */
	public Set getClasses();

	/**
	 * Get the datatype registered to handle the specified
	 * class.  If no match is found, null is returned.
	 *
	 * @param  c   the class to get a datatype for
	 *
	 * @return     the datatype registered to this class
	 *
	 */
	public Datatype getDatatype(Class c);

	/**
	 * Get the datatype registered to handle the specified
	 * Dowry type.  If no match is found, null is returned.
	 *
	 * @param  type  the string Dowry type to get a datatype
	 *               for
	 *
	 * @return       the datatype registered to this type
	 *
	 */
	public Datatype getDatatypeByType(String type);

	/**
	 * Returns the datatype instances that are registered.
	 *
	 * @return  a Set of Datatype objects registered
	 *
	 */
	public Set getDatatypes();
}