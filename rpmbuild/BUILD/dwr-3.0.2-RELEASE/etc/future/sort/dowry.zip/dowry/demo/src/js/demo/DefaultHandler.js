$package("demo");

/**
 * A default baseclass for our handlers just allows us to
 * provide some basic DOM manipulation utilities.  In
 * practice, these are probably better handled by widgets,
 * but good enough for our purposes.
 *
 */
$class("DefaultHandler").$as(
{
    /**
     * Creates a button element with the specified id and
     * value.
     *
     * @param id           the id of the button element
     *
     * @param value        the value of the button
     *
     * @param func         the onclick function for this
     *                     button
     *
     * @param btnParent    the parent to make this button a
     *                     child of
     *
     * @param conditional  if the button should only be
     *                     conditionally included, you can
     *                     provide a boolean indicating
     *                     whether or not to actually create
     *                     the button (yes, you could put
     *                     the create button call in an if
     *                     statement, but this cleans up
     *                     the caller code)
     *
     * @return             an <input type="button"> element
     *                     containing with the specified id
     *                     and value
     *
     */
    createButton : function(id, value, func, btnParent, conditional)
    {
        var ele = null;

        // do not want to create a duplicate element!
        if (id != null && $(id) == null &&
            (conditional == null || conditional == true))
        {
            ele = document.createElement("input");
            ele.setAttribute("type", "button");
            ele.setAttribute("id", id);
            if (value != null)
            {
                ele.setAttribute("value", value);
            }
            if (func != null)
            {
                Dowry.event.addEvent(ele, "click", func);
            }
            if (btnParent != null)
            {
                // make sure the parent is an object
                if (typeof btnParent != "object")
                {
                    btnParent = $(btnParent);
                }
                if (btnParent != null)
                {
                    btnParent.appendChild(ele);
                }
            }
        }

        return ele;
    },

    /**
     * Creates a link element to the specified URL, around
     * the specified text.
     *
     * @param url        the url to link to
     *
     * @param txt        the text to be linked
     *
     * @param newWindow  boolean whether or not this link
     *                   should open in a new window
     *
     * @return           an <a> element containing the
     *                   specified text, and that links to
     *                   the specified URL
     *
     */
    createLink : function(url, txt, newWindow)
    {
        if (url == null)
        {
        	url = "#";
        }

        var a = document.createElement("a");
        a.setAttribute("href", url);

        if (txt != null)
        {
            a.innerHTML = txt;
        }
        if (newWindow)
        {
            a.target = "_blank";
        }
        return a;
    },

    /**
     * Identitical to createLink(), except that it creates
     * a link that is presented as a hyperlink action or a
     * 'link button' style (eg. [Find An Account]).
     *
     * @param id           the unique id of the link button
     *
     * @param txt          the text to be linked
     *
     * @param urlOrFunc    the url to link to, or the
     *                     function to be exectued on click
     *
     * @param newWindow    boolean whether or not this link
     *                     should open in a new window
     *
     * @param linkParent   the parent to make this button a
     *                     child of
     *
     * @param conditional  if the button should only be
     *                     conditionally included, you can
     *                     provide a boolean indicating
     *                     whether or not to actually create
     *                     the button (yes, you could put
     *                     the create button call in an if
     *                     statement, but this cleans up
     *                     the caller code)
     *
     * @return           a <span> element containing the
     *                   specified link, enclosed in opening
     *                   and closing brackets
     *
     */
    createLinkButton : function(id,
                                txt,
                                urlOrFunc,
                                newWindow,
                                linkParent,
                                conditional)
    {
		var span = null;

        // do not want to create a duplicate element!
        if (id != null && $(id) == null &&
            (conditional == null || conditional == true))
        {
			var url = null;
			var func = null;
        	if (typeof urlOrFunc == "string")
			{
				url = urlOrFunc;
			}
			else
			{
				func = urlOrFunc;
			}

	        var openBracket = document.createElement("span");
	        openBracket.innerHTML = "[";

	        var link = this.createLink(url, txt, newWindow);

	        var closeBracket = document.createElement("span");
	        closeBracket.innerHTML = "]";

	        span = document.createElement("span");
	        span.id = id;
	        span.appendChild(openBracket);
	        span.appendChild(link);
	        span.appendChild(closeBracket);

			if (func != null)
			{
				Dowry.event.addEvent(link, "click", func);
			}

            if (linkParent != null)
            {
                // make sure the parent is an object
                if (typeof linkParent != "object")
                {
                    linkParent = $(linkParent);
                }
                if (linkParent != null)
                {
                    linkParent.appendChild(span);
                }
            }
		}

        return span;
    }
});