$package("demo");

$import("demo.DefaultHandler");

$class("PlayerListHandler").$extends("DefaultHandler").$as(
{
	PlayerListHandler : function()
	{
		var callback = Dowry.addValues.callback("playerList", $VALUE);
		DemoService.getPlayers(callback);
	}
});
