$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.DatetimeType");
$import("dowry.test.Test");

$class("DatetimeTypeTest").$extends("Test").$as(
{
	test : function()
	{
		var dt = new dowry.datatype.DatetimeType();
	}
});