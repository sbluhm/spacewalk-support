$package("dowry.datatype");

/**
 * Object representation of a string datatype.
 *
 */
$class("StringType").$extends("Datatype").$as(
{
    /**
     * Constant for the error message when validation finds
     * a value longer than the maximum length.
     *
     */
    ERROR_TOO_LONG : Dowry.msgs.getMessage("ERROR_TOO_LONG"),

    /**
     * Property indicating the maximum length of this
     * string.  The default is null (no maximum length).
     *
     */
    length : null,

    /**
     * Extends Datatype's <copde>toConfiguration()</code> to
     * include the extra property <code>maxLength</code>.
     * This property is included for use by interested
     * widgets.
     *
     * @param  id    the identifier for the field associated
     *               with this datatype (optional)
     *
     * @param  val   the field value associated with this
     *               datatype (optional)
     *
     * @return       an object containing the datatype
     *               information as a map
     *
     */
    toConfiguration : function(id, val)
    {
        var cfg = this.$super(arguments);

        cfg.maxLength = this.length;

        return cfg;
    },

    /**
     * Converts some raw value to a value of the appropriate
     * datatype.
     *
     * @param val  the original, raw value representation
     *
     * @return     the value converted to the appropriate
     *             datatype
     *
     */
    toDatatype : function(val)
    {
        // in this case, toDatatype() and
        // toFormattedString() do the same thing!
        return this.toFormattedString(val);
    },

    /**
     * Validates that:
     *
	 * <ol>
	 *  <li>  the value is provided, if required as
	 *        specified by map key <code>required</code>
	 *  </li>
	 *  <li>  the value does not exceed the length specified
	 *        by map key <code>length</code>
	 *  </li>
	 * </ol>
	 *
     * <p>
     * In practice, the 2nd validation is usually not
     * necessary, since the bound widget will likely
     * restrict us from exceeding the datatype's maximum
     * length.
     * </p>
     *
     * @param val    a value representation to be validated
     *
     * @return       the string error message, if the
     *               input is invalid; otherwise, null
     *
     */
    validate : function(val)
    {
        var msg = this.$super(arguments);

        if (msg == null &&
            val != null &&
            this.length != null)
        {
        	if (typeof val != "string")
        	{
	            val = val.toString();
	        }

            if (val.length > this.length)
            {
                msg = this.ERROR_TOO_LONG;
            }
        }

        return msg;
    }
});
