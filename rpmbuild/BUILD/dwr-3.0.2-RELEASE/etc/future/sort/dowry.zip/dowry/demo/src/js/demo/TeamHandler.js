$package("demo");

$import("demo.DefaultHandler");

$class("TeamHandler").$extends("DefaultHandler").$as(
{

	/**
	 * Creates a new instance of the handler.
	 *
	 */
	TeamHandler : function()
	{
		this.initEvents();
		this.initDropdowns();
		this.initOriginalValue();
		this.initButtons();
	},

	/**
	 * Initialize the buttons on the page.
	 *
	 */
	initButtons : function()
	{
		var url = "Player.html";
		var id = Dowry.getValue("teamId");
		if (id != null)
		{
			url = url + "?team.id="+id;
		}

		this.createLinkButton("addPlayerButton",
		                      "New Player",
		                      url,
		                      false,
		                      "newPlayerBar");

		this.createButton("saveButton",
		                  "Save",
		                  this.preSave,
		                  "buttonBar");
	},

	/**
	 * Initialize the dropdowns with the available options.
	 *
	 */
	initDropdowns : function()
	{
		// populate our division dropdowns
		var func = Dowry.addValues.callback("division", $VALUE);
		DemoService.getDivisions(func);

	},

	/**
	 * Initialize various Ajax events.
	 *
	 */
	initEvents : function()
	{
	},

	/**
	 * Initializes the original value.  It does so by
	 * retrieving the id from the query string, and if
	 * present, using that id to fetch the associated
	 * player object.  It then continues page
	 * intiialization.
	 *
	 */
	initOriginalValue : function()
	{
		var obj = Dowry.receiveObject();

		if (obj && obj.id)
		{
			var func = this.populateElements.callback($VALUE);
			DemoService.getTeam(obj.id, func);
		}
	},

	/**
	 * Populates the HTML elements based on the object model
     * representation.
     *
	 */
	populateElements : function(team)
	{
		Dowry.removeAllValues("players");

		Dowry.populateElements("Team", team);
		if (team)
		{
			Dowry.populateElements("Location", team.location);
			Dowry.populateElements("Owner", team.owner);
			Dowry.addValues("players", team.players);
		}
	},

	/**
	 * Populates the object model representation.
	 *
	 */
	populateObject : function()
	{
		var o = Dowry.populateObject("Team");
		if (o)
		{
			o.location = Dowry.populateObject("Location");
			o.owner = Dowry.populateObject("Owner");
		}

		return o;
	},

	/**
	 * Perform basic pre-save prep work, including
	 * validating the form input.
	 *
	 */
	preSave : function()
	{
		Dowry.validate(this.save);
	},

	/**
	 * Event fired when the user clicks the Save button.
	 *
	 */
	save : function(ok)
	{
		if (ok)
		{
			var val = this.populateObject();
			DemoService.saveTeam(val, this.postSave);
		}
	},

	/**
	 * Post-save?
	 *
	 */
	postSave : function(id)
	{
        Dowry.setValue("id", id);
        alert("saved");
	}

});