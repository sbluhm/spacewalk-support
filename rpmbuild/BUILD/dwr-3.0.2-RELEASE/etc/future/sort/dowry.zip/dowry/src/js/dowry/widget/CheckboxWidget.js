$package("dowry.widget");

/**
 * Object represenation of a UI widget that knows how to
 * handle checkboxes or radio buttons.
 *
 */
$class("CheckboxWidget").$extends("Widget").$as(
{
	/**
	 * Construct a new instance of CheckboxWidget.  This
	 * deals with issues with the checkbox displaying
	 * error messages.
	 *
	 * @param ele    the element (or ID of the element)
	 *               to bind to this datatype
	 *
	 */
	CheckboxWidget : function(ele)
	{
		this.$super(arguments);

		ele = this.getElement();
		if (ele != null)
		{
	        // apparently, a checkbox can't have a title
	        // (ie. the tooltip) in ie... so when we
	        // prepare, we will put an annonymous span
	        // around the select... but even this is *far*
	        // from perfect...
	        var span = this._createEnclosingSpan(ele);
		}
	},

	/**
	 * Gets the value of the bound element, represented as a
	 * type appropriate for the element's datatype.
	 *
	 * @return  the value
	 *
	 */
	getValue : function()
	{
		var val = null;

		var ele = this.getElement();
		if (ele && !ele.disabled)
		{
			val = ele.checked;

			// convert the raw value
			var dt = this.getDatatype();
			if (dt)
			{
				val = dt.toDatatype(val);
			}
		}

		return val;
	},

	/**
	 * Sets the value of the bound element, using a type
	 * appropriate for the element's datatype.
	 *
	 * @param val  the value to set
	 *
	 */
	setValue : function(val)
	{
		var ele = this.getElement();
		if (ele)
		{
			// convert the provided value
			// to a boolean
			var dt = this.getDatatype();
			if (dt)
			{
				val = dt.toFormattedString(val);
			}

			if (typeof val != "boolean")
			{
				val = (val == "true");
			}

			ele.checked = val;
		}
	},

    /**
     * Sets the error message on the widget.  If a non-null
     * error message is provided, this will make the UI
     * field display as <code>invalid</code> with the
     * message appearing in the tooltip.  A null message
     * will remove any error currently being displayed.
     *
     * @param  msg   the message
     *
     */
    setErrorMessage : function(msg)
    {
		var ele = this.getElement();

		// update both the element
		// *and* its enclosing span
		if (ele && ele.parentNode)
		{
			this._setErrorMessageImpl(ele.parentNode, msg);
		}

		this.$super(arguments);
    },

	/**
	 * When the CheckboxWidget is started, associate an
	 * event to validate the selection.
	 *
	 */
	start : function()
	{
		var ele = this.getElement();
		if (ele)
		{
			Dowry.event.addEvent(ele, "change", this.validate);
		}
	}
});