$package("demo");

$import("demo.DefaultHandler");

$class("TeamListHandler").$extends("DefaultHandler").$as(
{
	TeamListHandler : function()
	{
		var callback = Dowry.addValues.callback("teamList", $VALUE);
		DemoService.getTeams(callback);
	}
});
