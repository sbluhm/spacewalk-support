$package("dowry.util");

$import("dowry.util.MessageUtils");
$import("dowry.test.Test");

$class("MessageUtilsTest").$extends("Test").$as(
{
	setup : function()
	{
		var bundle =
		{
			FOO : "hello",
			BAR : "world",
			BAZ : "hello, {0}"
		};

		this.msgs = new dowry.util.MessageUtils(bundle);
	},

	testGetMessages : function()
	{
		this.assertEqual(this.msgs.getMessage("FOO"), "hello");
		this.assertEqual(this.msgs.getMessage("BAR"), "world");
		this.assertEqual(this.msgs.getMessage("BAZ", ["Tim"]), "hello, Tim");
		this.assertEqual(this.msgs.getMessage("BAZ"), "hello, {0}");
		this.assertEqual(this.msgs.getMessage("unmapped"), "unmapped");
		this.assertEqual(this.msgs.getMessage("unmapped {0}", ["Tim"]), "unmapped {0}");
	},

	teardown : function()
	{
		this.msgs = null;
	}
});