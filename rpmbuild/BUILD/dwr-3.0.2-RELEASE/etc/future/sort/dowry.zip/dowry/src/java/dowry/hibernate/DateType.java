package dowry.hibernate;

import java.text.*;
import java.util.*;
import org.hibernate.mapping.Property;
import dowry.*;

/**
 * Object representation of a Date datatype.
 *
 */
public class DateType
    extends dowry.datatype.DateType
    implements HibernateType
{
	/**
	 * Generates a map of attributes for the specified
	 * Hibernate property, based on the rules of this
	 * datatype.
	 *
	 * @param entityMapper  a handle back to the entity
	 *                      mapper processing the Hibernate
	 *                      configuration
	 *
	 * @param property      the Hibernate property
	 *
	 * @return              a Map containing the relevant
	 *                      Dowry attributes
	 *
	 */
	public Map toConfiguration(HibernateEntityMapper entityMapper,
	                           Property property)
	{
		Map cfg = new HashMap();

		String propertyType = entityMapper.getPropertyType(property);
		cfg.put(JAVA_CLASS, propertyType);
		cfg.put(TYPE, entityMapper.toType(propertyType));
		cfg.put(REQUIRED, new Boolean(!property.isOptional()));

		return cfg;
	}
}