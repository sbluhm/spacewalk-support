$package("dowry.datatype");

$import("Dowry");
$import("dowry.datatype.StringType");
$import("dowry.test.Test");

$class("StringTypeTest").$extends("Test").$as(
{
	testToConfiguration : function()
	{
		var dt = new dowry.datatype.StringType();
		dt.length = 8;
      	this.assertEqual(dt.toConfiguration().$class, "dowry.datatype.StringType");
      	this.assertEqual(dt.toConfiguration().maxLength, 8);
	},

	testToDatatype : function()
	{
		var dt = new dowry.datatype.StringType();
      	this.assertEqual(dt.toDatatype("  test  "), "test");
      	this.assertEqual(dt.toDatatype("test"), "test");
      	this.assertEqual(dt.toDatatype("test   "), "test");
      	this.assertEqual(dt.toDatatype("  test"), "test");
	},

	testValidate : function()
	{
		var dt = new dowry.datatype.StringType();
		this.assertNull(dt.validate(null));
		this.assertNull(dt.validate("blah"));
		this.assertNull(dt.validate("something"));
		this.assertNull(dt.validate(12345));
		this.assertNull(dt.validate(12345678901));
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertEqual(dt.required, false);
		this.assertNull(dt.length);

		var dt = new dowry.datatype.StringType();
		dt.required = true;
		this.assertNull(dt.length);
		this.assertEqual(dt.validate(null), dt.ERROR_REQUIRED);
		this.assertNull(dt.validate("blah"));
		this.assertNull(dt.validate("something"));
		this.assertNull(dt.validate(12345));
		this.assertNull(dt.validate(12345678901));
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertEqual(dt.required, true);

		var dt = new dowry.datatype.StringType();
		dt.required = false;
		dt.length = 10;
		this.assertNull(dt.validate(null));
		this.assertNull(dt.validate("blah"));
		this.assertNull(dt.validate("something"));
		this.assertEqual(dt.validate("abcdefghijk"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate("abcdefghijklm"), dt.ERROR_TOO_LONG);
		this.assertNull(dt.validate(12345));
		this.assertEqual(dt.validate(12345678901), dt.ERROR_TOO_LONG);
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertEqual(dt.required, false);
		this.assertEqual(dt.length, 10);

		var dt = new dowry.datatype.StringType();
		dt.required = true;
		dt.length = 4;
		this.assertEqual(dt.validate(null), dt.ERROR_REQUIRED);
		this.assertNull(dt.validate("blah"));
		this.assertEqual(dt.validate("something"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate("abcdefghijk"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate("abcdefghijklm"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate(12345), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate(12345678901), dt.ERROR_TOO_LONG);
		this.assertNull(dt.validate(true));
		this.assertEqual(dt.validate(false), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.required, true);
		this.assertEqual(dt.length, 4);

		var dt = new dowry.datatype.StringType();
		dt.length = 8;
		this.assertNull(dt.validate(null));
		this.assertNull(dt.validate("blah"));
		this.assertEqual(dt.validate("something"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate("abcdefghijk"), dt.ERROR_TOO_LONG);
		this.assertEqual(dt.validate("abcdefghijklm"), dt.ERROR_TOO_LONG);
		this.assertNull(dt.validate(12345));
		this.assertEqual(dt.validate(12345678901), dt.ERROR_TOO_LONG);
		this.assertNull(dt.validate(true));
		this.assertNull(dt.validate(false));
		this.assertEqual(dt.required, false);
		this.assertEqual(dt.length, 8);
	}
});