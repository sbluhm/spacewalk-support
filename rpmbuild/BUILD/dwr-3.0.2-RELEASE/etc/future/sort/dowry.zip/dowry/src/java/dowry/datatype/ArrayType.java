package dowry.datatype;

import java.util.*;
import dowry.*;

/**
 * Object representation of an array datatype.
 *
 */
public class ArrayType extends AbstractType
{
	public static final String NAME          = Messages.get("array");
	public static final String ELEMENT_TYPE  = "elementType";

	/**
	 * Gets the name of the Javascript class that serves
	 * as the client side equivalent to this Java Datatype.
	 *
	 * @return  the string Javascript class name of the
	 *          datatype
	 *
	 */
	public String getJsClass()
	{
		return ArrayType.class.getName();
	}

	/**
	 * Tests if this datatype is a handler for the
	 * specified Dowry type name.
	 *
	 * @param  typeName  the Dowry type name
	 *
	 * @return           true if this datatype can handle
	 *                   the specified type name; false
	 *                   otherwise
	 *
	 */
	public boolean isType(String typeName)
	{
		return (typeName != null && typeName.equals(NAME));
	}

	/**
	 * Converts the Java class for this datatype to the type
	 * representation used by Dowry on the client.
	 *
	 * <p>
	 * This implementation returns 'array'.
	 * </p>
	 *
	 * @param  c   the class to get the type name for
	 *
	 * @return     the string representation of type to be
	 *             used in Dowry
	 *
	 */
	public String toType(Class c)
	{
		return NAME;
	}

	/**
	 * Validates that:
	 *
	 * TODO: how do we validate an array on the server???
	 *
	 * @param  cfg  a map containing all the configuration
	 *              information relevant to the local
	 *              representation of this datatype
	 *
	 * @return      the string validation error message,
	 *              if the validation fails; null otherwise
	 *
	 */

	public String validate(Map cfg)
	{
		return null;
	}
}